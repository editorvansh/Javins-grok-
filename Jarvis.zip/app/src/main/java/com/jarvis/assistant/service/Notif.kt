package com.jarvis.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.ui.MainActivity

object Notif {
    private const val CH = "jarvis"

    fun channel(c: Context) {
        c.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Jarvis", NotificationManager.IMPORTANCE_LOW))
    }

    fun listening(c: Context): Notification {
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(c, 1,
            Intent(c, WakeService::class.java).setAction(WakeService.STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Jarvis is listening for \"Jarvis\"")
            .setContentText("Microphone is on. Tap Stop to turn it off.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }

    /** After reboot Android won't let us open the mic by ourselves, so we ask the user with one tap. */
    fun resumeAfterBoot(c: Context) {
        channel(c)
        val i = Intent(c, MainActivity::class.java).putExtra(MainActivity.EXTRA_RESUME_WAKE, true)
        val pi = PendingIntent.getActivity(c, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Jarvis is ready")
            .setContentText("Tap to turn on \"Jarvis\" listening.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        runCatching { c.getSystemService(NotificationManager::class.java).notify(2, n) }
    }
}
