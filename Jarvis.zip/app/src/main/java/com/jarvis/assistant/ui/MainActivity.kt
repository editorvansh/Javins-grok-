package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.assistant.core.JStatus
import com.jarvis.assistant.core.Msg
import com.jarvis.assistant.core.Prefs
import com.jarvis.assistant.service.WakeService
import kotlin.math.PI
import kotlin.math.sin

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF141B2E)
private val Cyan = Color(0xFF22D3EE)
private val TextMain = Color(0xFFE2E8F0)
private val TextDim = Color(0xFF94A3B8)

class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_RESUME_WAKE = "resume_wake" }

    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, onPrimary = Bg, background = Bg, surface = Panel, onSurface = TextMain,
            )) { JarvisScreen(vm, ::setWake) }
        }
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }

    private fun handle(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_ASSIST || i.action == Intent.ACTION_VOICE_COMMAND) {
            window.decorView.post { vm.listen() }
        }
        if (i.getBooleanExtra(EXTRA_RESUME_WAKE, false)) setWake(true)
    }

    fun setWake(on: Boolean) {
        val si = Intent(this, WakeService::class.java)
        if (on) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Please allow the microphone first.", Toast.LENGTH_LONG).show(); return
            }
            Prefs.setWake(this, true)
            ContextCompat.startForegroundService(this, si)
        } else {
            Prefs.setWake(this, false)
            stopService(si)
        }
    }
}

@Composable
fun JarvisScreen(vm: JarvisViewModel, onToggleWake: (Boolean) -> Unit) {
    val status by vm.status.collectAsState()
    val msgs by vm.messages.collectAsState()
    val pending by vm.pending.collectAsState()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        perms.launch(list.toTypedArray())
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    fun send() { if (input.isNotBlank()) { vm.send(input); input = "" } }

    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding().padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { showSettings = true }) { Text("Settings", color = Cyan) }
        }
        Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
            Orb(status, Modifier.size(150.dp).clickable { vm.listen() })
        }
        Text(status.label, color = TextDim, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { Bubble(it) }
        }

        if (pending != null) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.send("yes") }, modifier = Modifier.weight(1f)) { Text("Yes, do it") }
                OutlinedButton(onClick = { vm.send("no") }, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type a command…") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (input.isBlank()) vm.listen() else send() }) {
                Text(if (input.isBlank()) "Talk" else "Send")
            }
        }
    }
    if (showSettings) SettingsDialog({ showSettings = false }, onToggleWake)
}

@Composable
fun Bubble(m: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (m.fromUser) Cyan.copy(alpha = 0.18f) else Panel,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 300.dp),
        ) { Text(m.text, color = TextMain, modifier = Modifier.padding(12.dp)) }
    }
}

@Composable
fun Orb(status: JStatus, modifier: Modifier) {
    val tr = rememberInfiniteTransition(label = "orb")
    val t by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "t")
    val c = Color(status.argb)
    Canvas(modifier) {
        val r = size.minDimension / 2
        val w = (t * 2 * PI).toFloat()
        val pulse = when (status) {
            JStatus.LISTENING -> 0.8f + 0.2f * sin(w * 2)
            JStatus.SPEAKING -> 0.85f + 0.15f * sin(w * 3)
            else -> 0.88f + 0.04f * sin(w)
        }
        drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.7f), Color.Transparent), center, r), r * pulse)
        drawCircle(c, r * 0.4f)
        if (status == JStatus.THINKING || status == JStatus.EXECUTING) {
            drawArc(c, t * 360f, 100f, false,
                topLeft = Offset(center.x - r * 0.65f, center.y - r * 0.65f),
                size = Size(r * 1.3f, r * 1.3f), style = Stroke(r * 0.08f, cap = StrokeCap.Round))
        }
    }
}

@Composable
fun SettingsDialog(onDismiss: () -> Unit, onToggleWake: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var g by remember { mutableStateOf(Prefs.gemini(ctx)) }
    var e by remember { mutableStateOf(Prefs.eleven(ctx)) }
    var v by remember { mutableStateOf(Prefs.voiceId(ctx)) }
    var wake by remember { mutableStateOf(Prefs.wake(ctx)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        confirmButton = { TextButton(onClick = { Prefs.save(ctx, g, e, v); onDismiss() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(g, { g = it }, label = { Text("Gemini API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(e, { e = it }, label = { Text("ElevenLabs API key (optional)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(v, { v = it }, label = { Text("ElevenLabs voice ID") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Say \"Jarvis\" to wake", Modifier.weight(1f))
                    Switch(wake, { wake = it; onToggleWake(it) })
                }
                Text("Keeps the microphone on with a visible notification. Uses extra battery.",
                    color = TextDim, fontSize = 12.sp)
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }) { Text("Allow floating orb over other apps") }
            }
        },
    )
}
