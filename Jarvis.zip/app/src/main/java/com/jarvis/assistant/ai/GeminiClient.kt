package com.jarvis.assistant.ai

import com.jarvis.assistant.core.Msg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

/** Structured response from the model. The app validates `action` against an allow-list. */
data class JarvisReply(val speech: String, val action: String?, val params: JSONObject, val confirm: Boolean) {
    companion object {
        fun parse(raw: String): JarvisReply {
            val clean = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val o = JSONObject(clean)
            val a = if (o.isNull("action")) null else o.optString("action").trim().ifBlank { null }
            return JarvisReply(
                speech = o.optString("speech"),
                action = a,
                params = o.optJSONObject("params") ?: JSONObject(),
                confirm = o.optBoolean("confirm", false),
            )
        }
    }
}

class GeminiClient(private val apiKey: String) {
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()

    suspend fun ask(history: List<Msg>): JarvisReply = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        history.forEach { m ->
            contents.put(JSONObject()
                .put("role", if (m.fromUser) "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", m.text))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt()))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val msg = runCatching { JSONObject(s).getJSONObject("error").getString("message") }.getOrNull()
                throw IOException("Gemini error ${r.code}: ${msg ?: s.take(200)}")
            }
            val text = JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            JarvisReply.parse(text)
        }
    }

    private fun systemPrompt(): String {
        val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm, EEEE"))
        return """
You are JARVIS, a calm, witty, concise voice assistant on the user's Android phone.
Current local date/time: $now.
Replies are spoken aloud, so keep "speech" short (1-3 sentences), no markdown, no emojis.

ALWAYS answer with a single JSON object:
{"speech": string, "action": string or null, "params": object, "confirm": boolean}

Use action=null for chat and questions. Otherwise pick ONE tool:
open_app {name}                     e.g. "YouTube", "WhatsApp"
search_web {query}
open_url {url}                      https only
call_contact {name}                 opens dialer with the number
show_dialer {number}
send_message_draft {to, body}       opens SMS app with a draft
set_alarm {hour (0-23), minute, label}
set_timer {seconds, label}
create_calendar_event {title, start "yyyy-MM-ddTHH:mm", duration_minutes}   also use for reminders
open_calendar {}                    for "what's on my schedule"
open_camera {}
toggle_flashlight {on: boolean}
open_maps {query}
navigate_to {query}
play_media {query}                  empty query = resume playback
pause_media {} | resume_media {} | next_track {}
change_volume {direction: "up"|"down"|"mute"}
launch_settings {page: "wifi"|"bluetooth"|"display"|"battery"|"sound"|"general"}
get_battery_status {} | get_current_time {} | get_device_information {}

For get_* tools leave speech empty; the app speaks the result.
Set confirm=true for anything that contacts people or could be destructive.
You cannot see the screen or read notifications; say so politely if asked.
Never invent other action names.
""".trimIndent()
    }

    companion object { const val MODEL = "gemini-2.5-flash" }
}
