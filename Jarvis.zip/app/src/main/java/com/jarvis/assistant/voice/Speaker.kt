package com.jarvis.assistant.voice

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.jarvis.assistant.core.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import kotlin.coroutines.resume

/** ElevenLabs voice when a key is set, otherwise the phone's built-in voice. */
class Speaker(private val ctx: Context) : TextToSpeech.OnInitListener {
    private val system = TextToSpeech(ctx, this)
    private var ready = false
    private var player: MediaPlayer? = null
    private var done: (() -> Unit)? = null
    private val http = OkHttpClient()

    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS }

    fun stop() {
        player?.release(); player = null
        system.stop()
        val d = done; done = null; d?.invoke()
    }

    suspend fun speak(text: String) {
        stop()
        val key = Prefs.eleven(ctx)
        if (key.isNotBlank()) {
            try { playFile(fetchEleven(key, text)); return }
            catch (e: Exception) { Log.w("Jarvis", "ElevenLabs failed, using system voice", e) }
        }
        speakSystem(text)
    }

    private suspend fun fetchEleven(key: String, text: String): File = withContext(Dispatchers.IO) {
        val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2").toString()
        val req = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/${Prefs.voiceId(ctx)}?output_format=mp3_44100_128")
            .header("xi-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("ElevenLabs ${r.code}: ${r.body?.string()?.take(200)}")
            File(ctx.cacheDir, "jarvis_tts.mp3").apply { writeBytes(r.body!!.bytes()) }
        }
    }

    private suspend fun playFile(f: File) = suspendCancellableCoroutine { cont ->
        done = { if (cont.isActive) cont.resume(Unit) }
        val mp = MediaPlayer()
        player = mp
        mp.setDataSource(f.path)
        mp.setOnCompletionListener { done?.invoke(); done = null }
        mp.setOnErrorListener { _, _, _ -> done?.invoke(); done = null; true }
        mp.prepare()
        mp.start()
    }

    private suspend fun speakSystem(text: String) = suspendCancellableCoroutine { cont ->
        if (!ready) { cont.resume(Unit); return@suspendCancellableCoroutine }
        done = { if (cont.isActive) cont.resume(Unit) }
        system.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { done?.invoke(); done = null }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { done?.invoke(); done = null }
        })
        system.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }
}
