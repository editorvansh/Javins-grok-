package com.jarvis.assistant.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import com.jarvis.assistant.core.JStatus
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** The small glowing floating orb shown over other apps. */
class OrbView(ctx: Context) : View(ctx) {
    var status: JStatus = JStatus.IDLE
        set(v) { field = v; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = RectF()
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = min(width, height) / 2f
        val color = status.argb.toInt()
        val w = (t * 2 * PI).toFloat()
        val pulse = when (status) {
            JStatus.LISTENING -> 0.8f + 0.2f * sin(w * 2)
            JStatus.SPEAKING -> 0.85f + 0.15f * sin(w * 3)
            else -> 0.88f + 0.04f * sin(w)
        }
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * pulse, paint)
        paint.shader = null
        paint.color = color
        canvas.drawCircle(cx, cy, r * 0.4f, paint)
        if (status == JStatus.THINKING || status == JStatus.EXECUTING) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = r * 0.08f; paint.strokeCap = Paint.Cap.ROUND
            arc.set(cx - r * 0.65f, cy - r * 0.65f, cx + r * 0.65f, cy + r * 0.65f)
            canvas.drawArc(arc, t * 360f, 100f, false, paint)
        }
    }
}
