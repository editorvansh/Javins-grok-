package com.jarvis.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.jarvis.assistant.core.JarvisEngine

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = JarvisEngine.get(app)
    val status = engine.status
    val messages = engine.messages
    val pending = engine.pending
    fun send(text: String) = engine.submit(text)
    fun listen() = engine.listen()
}
