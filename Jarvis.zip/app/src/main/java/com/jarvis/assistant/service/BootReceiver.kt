package com.jarvis.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.jarvis.assistant.core.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || !Prefs.wake(c)) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            ContextCompat.startForegroundService(c, Intent(c, WakeService::class.java))
        } else {
            // Android 11+ blocks background microphone starts; one tap restores it.
            Notif.resumeAfterBoot(c)
        }
    }
}
