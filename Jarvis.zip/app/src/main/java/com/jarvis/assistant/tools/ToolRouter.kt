package com.jarvis.assistant.tools

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** The ONLY place Android actions happen. Anything not in ALLOWED is refused. */
class ToolRouter(private val ctx: Context) {

    companion object {
        val ALLOWED = setOf(
            "open_app", "search_web", "open_url", "call_contact", "show_dialer", "send_message_draft",
            "set_alarm", "set_timer", "create_calendar_event", "open_calendar", "open_camera",
            "toggle_flashlight", "open_maps", "navigate_to", "play_media", "pause_media", "resume_media",
            "next_track", "change_volume", "launch_settings", "get_battery_status", "get_current_time",
            "get_device_information",
        )
        /** Always asks the user "yes/no" first. */
        val SENSITIVE = setOf("call_contact", "show_dialer", "send_message_draft")
    }

    fun execute(action: String, p: JSONObject): String {
        if (action !in ALLOWED) return "I'm not allowed to do that."
        return try {
            when (action) {
                "open_app" -> openApp(p.optString("name"))
                "search_web" -> view("https://www.google.com/search?q=" + Uri.encode(p.optString("query")))
                "open_url" -> {
                    val u = p.optString("url")
                    if (u.startsWith("https://") || u.startsWith("http://")) view(u) else "That link doesn't look safe."
                }
                "call_contact" -> {
                    val n = resolveNumber(p.optString("name")) ?: return "I couldn't find that contact. Make sure contacts permission is on."
                    start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
                }
                "show_dialer" -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(p.optString("number")))))
                "send_message_draft" -> {
                    val n = resolveNumber(p.optString("to")) ?: ""
                    start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))
                        .putExtra("sms_body", p.optString("body")))
                }
                "set_alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, p.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, p.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, p.optString("label", "Jarvis alarm"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "set_timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, p.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, p.optString("label", "Jarvis timer"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "create_calendar_event" -> {
                    val begin = runCatching {
                        LocalDateTime.parse(p.optString("start")).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    }.getOrDefault(System.currentTimeMillis() + 3_600_000)
                    val end = begin + p.optInt("duration_minutes", 30) * 60_000L
                    start(Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, p.optString("title", "Reminder"))
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end))
                }
                "open_calendar" -> view("content://com.android.calendar/time/" + System.currentTimeMillis())
                "open_camera" -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                "toggle_flashlight" -> torch(p.optBoolean("on", true))
                "open_maps" -> view("geo:0,0?q=" + Uri.encode(p.optString("query")))
                "navigate_to" -> try {
                    start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(p.optString("query")))))
                } catch (e: ActivityNotFoundException) {
                    view("geo:0,0?q=" + Uri.encode(p.optString("query")))
                }
                "play_media" -> {
                    val q = p.optString("query")
                    if (q.isBlank()) mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                    else start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(SearchManager.QUERY, q)
                        .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"))
                }
                "pause_media" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
                "resume_media" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                "next_track" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
                "change_volume" -> volume(p.optString("direction", "up"))
                "launch_settings" -> start(Intent(when (p.optString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }))
                "get_battery_status" -> {
                    val bm = ctx.getSystemService(BatteryManager::class.java)
                    val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    "Battery is at $pct percent" + if (bm.isCharging) ", and charging." else "."
                }
                "get_current_time" -> "It's " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("h:mm a, EEEE d MMMM")) + "."
                "get_device_information" -> "This is a ${Build.MANUFACTURER} ${Build.MODEL} running Android ${Build.VERSION.RELEASE}."
                else -> "I'm not allowed to do that."
            }
        } catch (e: ActivityNotFoundException) {
            "No app on this phone can handle that."
        } catch (e: SecurityException) {
            "I need a permission for that. Please allow it in the app settings."
        } catch (e: Exception) {
            "That didn't work: ${e.message}"
        }
    }

    private fun start(i: Intent): String { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "" }
    private fun view(url: String) = start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val target = name.lowercase().trim()
        if (target.isBlank()) return "Which app should I open?"
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == target }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(target) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(target.replace(" ", "")) }
            ?: return "I couldn't find an app called $name."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "I can't open $name."
        return start(launch)
    }

    private fun resolveNumber(nameOrNumber: String): String? {
        if (nameOrNumber.matches(Regex("[+\\d][\\d\\s-]{2,}"))) return nameOrNumber.replace(" ", "")
        if (nameOrNumber.isBlank()) return null
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(nameOrNumber))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "This phone has no flashlight."
        cm.setTorchMode(id, on)
        return ""
    }

    private fun mediaKey(code: Int): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ""
    }

    private fun volume(dir: String): String {
        val am = ctx.getSystemService(AudioManager::class.java)
        val adj = when (dir) {
            "down" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> AudioManager.ADJUST_RAISE
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, adj, AudioManager.FLAG_SHOW_UI)
        return ""
    }
}
