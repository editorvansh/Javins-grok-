package com.jarvis.assistant.core

import android.content.Context
import com.jarvis.assistant.ai.GeminiClient
import com.jarvis.assistant.ai.JarvisReply
import com.jarvis.assistant.tools.ToolRouter
import com.jarvis.assistant.voice.Listener
import com.jarvis.assistant.voice.Speaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class JStatus(val label: String, val argb: Long) {
    IDLE("Tap the orb and speak", 0xFF38BDF8),
    LISTENING("Listening…", 0xFF22D3EE),
    THINKING("Thinking…", 0xFFF59E0B),
    SPEAKING("Speaking…", 0xFF34D399),
    EXECUTING("Working on it…", 0xFF60A5FA),
    ERROR("Something went wrong", 0xFFEF4444),
}

data class Msg(val fromUser: Boolean, val text: String)

/**
 * Voice pipeline: speech -> text -> Gemini -> (validated action) -> spoken reply.
 * Shared by the app screen and the background wake service.
 */
class JarvisEngine private constructor(private val app: Context) {
    val status = MutableStateFlow(JStatus.IDLE)
    val messages = MutableStateFlow<List<Msg>>(emptyList())
    val pending = MutableStateFlow<JarvisReply?>(null)

    /** Lets the wake service free the microphone before we listen. */
    var beforeListen: (() -> Unit)? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val speaker = Speaker(app)
    private val listener = Listener(app)
    private val tools = ToolRouter(app)

    fun listen() {
        beforeListen?.invoke()
        speaker.stop()
        status.value = JStatus.LISTENING
        listener.listen { text ->
            if (text.isNullOrBlank()) status.value = JStatus.IDLE else submit(text)
        }
    }

    fun stop() {
        listener.stop(); speaker.stop(); status.value = JStatus.IDLE
    }

    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        add(Msg(true, t))

        val waiting = pending.value
        if (waiting != null) {
            pending.value = null
            val yes = listOf("yes", "yeah", "yep", "sure", "do it", "go ahead", "confirm", "ok", "haan", "ha")
            scope.launch {
                if (yes.any { t.lowercase().contains(it) }) runAction(waiting) else say("Okay, cancelled.")
            }
            return
        }

        scope.launch {
            val key = Prefs.gemini(app)
            if (key.isBlank()) { fail("Please add your Gemini API key in Settings."); return@launch }
            status.value = JStatus.THINKING
            try {
                val history = messages.value.takeLast(20).dropWhile { !it.fromUser }
                val reply = GeminiClient(key).ask(history)
                val action = reply.action
                when {
                    action == null -> say(reply.speech.ifBlank { "Done." })
                    action !in ToolRouter.ALLOWED -> say("Sorry, I'm not allowed to do that.")
                    action in ToolRouter.SENSITIVE || reply.confirm -> {
                        pending.value = reply
                        say(reply.speech.ifBlank { "Should I go ahead?" } + " Say yes or no.")
                    }
                    else -> runAction(reply)
                }
            } catch (e: Exception) {
                fail("I couldn't reach my brain: ${e.message}")
            }
        }
    }

    private suspend fun runAction(r: JarvisReply) {
        status.value = JStatus.EXECUTING
        val result = tools.execute(r.action ?: return, r.params)
        say(listOf(r.speech, result).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Done." })
    }

    private suspend fun say(text: String) {
        add(Msg(false, text))
        status.value = JStatus.SPEAKING
        speaker.speak(text)
        if (status.value == JStatus.SPEAKING) status.value = JStatus.IDLE
    }

    private suspend fun fail(text: String) {
        add(Msg(false, text))
        status.value = JStatus.ERROR
        speaker.speak(text)
        if (status.value == JStatus.ERROR) status.value = JStatus.IDLE
    }

    private fun add(m: Msg) { messages.value = (messages.value + m).takeLast(100) }

    companion object {
        @Volatile private var inst: JarvisEngine? = null
        fun get(c: Context): JarvisEngine =
            inst ?: synchronized(this) { inst ?: JarvisEngine(c.applicationContext).also { inst = it } }
    }
}
