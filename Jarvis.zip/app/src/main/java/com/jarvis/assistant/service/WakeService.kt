package com.jarvis.assistant.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import com.jarvis.assistant.core.JStatus
import com.jarvis.assistant.core.JarvisEngine
import com.jarvis.assistant.core.Prefs
import com.jarvis.assistant.voice.Listener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Optional "Jarvis" wake mode. Runs as a visible foreground service with a
 * permanent notification, listens for the word "Jarvis", then shows the
 * floating orb and handles the command without opening the full app.
 */
class WakeService : Service() {
    companion object { const val STOP = "com.jarvis.STOP" }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wake: Listener
    private lateinit var wm: WindowManager
    private var orb: OrbView? = null
    private var idleJob: Job? = null
    private val engine get() = JarvisEngine.get(this)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        wake = Listener(this)
        Notif.channel(this)
        val n = Notif.listening(this)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        engine.beforeListen = { wake.stop() }
        scope.launch { engine.status.collect { onStatus(it) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { Prefs.setWake(this, false); stopSelf() }
        return START_NOT_STICKY
    }

    private fun loop() {
        val s = engine.status.value
        if (s != JStatus.IDLE && s != JStatus.ERROR) return
        wake.listen { text ->
            val t = text?.lowercase().orEmpty()
            val i = t.indexOf("jarvis")
            if (i >= 0) {
                showOrb()
                val cmd = t.substring(i + 6).trim(' ', ',', '.', '!', '?')
                if (cmd.length > 2) engine.submit(cmd) else engine.listen()
            } else {
                scope.launch { delay(250); loop() }
            }
        }
    }

    private fun onStatus(s: JStatus) {
        orb?.status = s
        idleJob?.cancel()
        if (s == JStatus.IDLE) {
            idleJob = scope.launch {
                delay(2500)
                hideOrb()
                loop()
            }
        }
    }

    private fun showOrb() {
        if (orb != null || !Settings.canDrawOverlays(this)) return
        val size = (resources.displayMetrics.density * 72).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.BOTTOM or Gravity.END; x = 32; y = 240 }
        val v = OrbView(this)
        v.status = engine.status.value
        v.setOnClickListener { engine.listen() }
        v.setOnLongClickListener { engine.stop(); hideOrb(); true }
        wm.addView(v, lp)
        orb = v
    }

    private fun hideOrb() { orb?.let { runCatching { wm.removeView(it) } }; orb = null }

    override fun onDestroy() {
        engine.beforeListen = null
        wake.stop(); hideOrb(); scope.cancel()
        super.onDestroy()
    }
}
