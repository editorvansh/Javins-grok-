package com.jarvis.assistant.core

import android.content.Context

/** Stores the user's API keys and settings locally on the phone (never in the APK). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun gemini(c: Context) = sp(c).getString("gemini", "").orEmpty()
    fun eleven(c: Context) = sp(c).getString("eleven", "").orEmpty()
    fun voiceId(c: Context) = sp(c).getString("voice", "").orEmpty().ifBlank { "JBFqnCBsd6RMkjVDRZzb" }
    fun wake(c: Context) = sp(c).getBoolean("wake", false)
    fun save(c: Context, gemini: String, eleven: String, voice: String) =
        sp(c).edit().putString("gemini", gemini.trim()).putString("eleven", eleven.trim())
            .putString("voice", voice.trim()).apply()
    fun setWake(c: Context, on: Boolean) = sp(c).edit().putBoolean("wake", on).apply()
}
