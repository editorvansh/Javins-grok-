# JARVIS – voice-first AI assistant for Android

Kotlin · Jetpack Compose · Material 3 · Gemini · ElevenLabs · Android SpeechRecognizer

## Build the APK with ONLY a phone (no PC)

1. Create a free account on github.com and make a **new empty repository** called `Jarvis`.
2. Open the repo, then **Code -> Codespaces -> Create codespace** (works in a phone browser; use "Desktop site").
3. In the Codespace file panel, drag/upload `Jarvis.zip`, then in the terminal run:
   ```
   unzip Jarvis.zip && cp -r Jarvis/. . && rm -rf Jarvis Jarvis.zip
   git add . && git commit -m "JARVIS" && git push
   ```
4. Go to the repo's **Actions** tab. The "Build JARVIS APK" job runs automatically (~5 min).
5. Open the finished run, then download **jarvis-apk** at the bottom. Unzip it and install `app-debug.apk`
   (allow "Install unknown apps" for your browser/files app).

To rebuild after editing code, just push again.

## First run
1. Allow microphone, contacts and notifications.
2. **Settings**: paste your Gemini key (free at https://aistudio.google.com/apikey).
   ElevenLabs key + voice ID are optional; otherwise the phone's built-in voice is used.
3. Tap the orb and talk: "open YouTube", "set an alarm for 7 AM", "turn on the flashlight".
4. Optional: enable **Say "Jarvis" to wake** and **Allow floating orb**.
5. Optional: swipe down Quick Settings, then edit and add the **Jarvis** tile for one-tap voice.

## Architecture
```
ui/        MainActivity (Compose), JarvisViewModel
core/      JarvisEngine (voice pipeline + states), Prefs
ai/        GeminiClient – JSON structured replies {speech, action, params, confirm}
tools/     ToolRouter – allow-listed Android actions; the AI can never run anything else
voice/     Listener (SpeechRecognizer), Speaker (ElevenLabs, falls back to Android TTS)
service/   WakeService (foreground mic + floating orb), OrbView, BootReceiver, Quick Settings tile
```
Sensitive tools (calling, messages) always ask "yes/no" first, and they only open the dialer
or SMS draft. You press the final Call/Send button yourself.

## Honest Android limits
| Request | What JARVIS does |
|---|---|
| Always-on "Jarvis" wake word | Optional foreground service with permanent notification, using the system recognizer in a loop. Uses more battery; some phones beep each cycle. A true low-power hotword needs an on-device engine (e.g. Picovoice Porcupine, paid key). |
| Auto-start after reboot | Android 11+ forbids opening the mic in the background, so JARVIS shows a "Tap to turn on" notification after boot. On Android 10 and older, it starts automatically. |
| Direct calls / sending SMS silently | Not done on purpose. It opens the dialer or SMS draft for you to confirm. |
| Read screen / notifications | Not included (would need Accessibility or NotificationListener access, which Play restricts). |
| Replace Google Assistant | Real default-assistant role needs a VoiceInteractionService; the Quick Settings tile + ASSIST intent are used instead. |
| Opening apps from wake mode | Needs the "floating orb" (display over other apps) permission. |

API keys are stored only on your phone, never inside the APK.
