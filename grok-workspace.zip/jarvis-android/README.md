# JARVIS

Voice-first personal assistant for Android. You talk; JARVIS decides whether you are chatting or asking for a phone action, checks that action against an allow-list and a safety layer, then either does it, asks you, or refuses.

This is original software. It does not use Iron Man artwork, trademarks, or film audio.

## What it does

- Jetpack Compose UI: animated orb, chat, history, automations, settings, onboarding
- Gemini (`generateContent` REST, the current Gemini Developer API) as the reasoning brain, with manual function calling
- Optional proxy so the Gemini key stays off the device (`server-proxy/`)
- ElevenLabs text-to-speech, with Android `TextToSpeech` fallback
- Android `SpeechRecognizer` for speech-to-text
- Allow-listed tools: open apps, web, dialer, message drafts, alarms, timers, calendar drafts, reminders, camera, flashlight, maps, media keys, volume, settings, notifications, battery, time, device info, schedule, screen text, memory
- `ActionSafetyManager` classifies every action as low risk, confirmation required, or blocked. The model cannot set a "confirmed" flag
- Optional wake listening **only** inside a foreground service with a persistent notification and the system microphone indicator
- Optional overlay orb after the user grants "display over other apps"
- Boot resume only if the user opted in
- Visible, editable memory (Room) and automations (AlarmManager)

## Architecture

```
speech or keyboard
  -> AssistantEngine
  -> AssistantCoordinator
       -> GeminiRepository (or LocalCommandParser if Gemini is down)
       -> ToolRouter (allow-list)
       -> ActionSafetyManager
       -> ActionExecutor (Android intents and APIs)
  -> VoiceSpeaker (ElevenLabs, else Android TTS)
```

The model never receives a shell, never installs packages, and never gets a path that marks an action confirmed. `confirmedByUser` is set only after the person's next reply is a clear "yes".

Packages:

| Area | Path |
| --- | --- |
| Domain models | `app/src/main/java/com/jarvis/assistant/domain` |
| AI, tools, session | `.../ai` |
| Safety | `.../security` |
| Phone actions | `.../actions` |
| Voice | `.../voice` |
| Data | `.../data` |
| Background | `.../services`, `.../automation` |
| UI | `.../ui` |

## Requirements

- Android Studio (recent) or the Android SDK command line tools
- JDK 17
- `compileSdk` / `targetSdk` 36, `minSdk` 26
- A Gemini API key from Google AI Studio, **or** the proxy
- Optional ElevenLabs API key and voice id

## Setup

1. Open the `jarvis-android` directory in Android Studio.
2. Copy `local.properties.example` to `local.properties`.
3. Set `sdk.dir` to your Android SDK.
4. Leave the API key fields empty. Enter keys in the app under Settings. They are stored with EncryptedSharedPreferences and are not logged.
5. Debug builds can optionally seed empty storage from `GEMINI_API_KEY`, `ELEVENLABS_API_KEY`, and `GEMINI_PROXY_URL` in `local.properties`. **Release builds ignore those values** so they are not baked into a release APK.

### Gemini

Preferred: run the proxy and put only its URL in the app.

```bash
cd server-proxy
GEMINI_API_KEY=your_key node server.mjs
```

Then in the app set the proxy URL to `http://10.0.2.2:8787` (emulator) or your machine's LAN address. Cleartext is allowed only for `localhost` and `10.0.2.2`. Use HTTPS for anything else.

Personal sideload: paste a Gemini key in Settings. Do not ship a store build with an embedded key. Google's own guidance is to keep credentials off the device (Firebase AI Logic + App Check, or your backend). This project follows that by supporting a proxy and by refusing to put keys in release `BuildConfig`.

Default model: `gemini-2.5-flash`. You can switch to `gemini-flash-latest` or another model id in Settings.

### ElevenLabs

Settings → Voice → API key, voice id, speed, Test voice.

The request goes to `POST https://api.elevenlabs.io/v1/text-to-speech/{voiceId}`. If the key is missing or the call fails, Android TTS speaks instead.

The default voice id is ElevenLabs' public premade voice "Rachel" (`21m00Tcm4TlvDq8ikWAM`). Change it to any voice on your account.

## Permissions

Requested only when you use the feature. Denying one disables that feature, not the app.

| Permission | Why |
| --- | --- |
| Microphone | Speech recognition and optional wake listening |
| Notifications | Foreground-service status, reminders |
| Contacts | Resolve a spoken name. Nothing is uploaded by the app itself |
| Phone | Only if you turn on "Place calls directly". Default is the dialer |
| Camera | Flashlight (`CameraManager.setTorchMode`) |
| Calendar | Read today's events, or open a draft event |
| Overlay | Small orb over other apps |
| Exact alarms | Automations and reminders at a chosen time. Android may send you to a system screen |

Notification access and accessibility are separate system screens. Both are off until you enable them.

## Build

```bash
# debug APK
./gradlew assembleDebug

# unit tests
./gradlew testDebugUnitTest

# release bundle (after you create a keystore)
./gradlew bundleRelease
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

### Signed release

1. Create a keystore (Android Studio: Build → Generate Signed Bundle / APK, or `keytool`).
2. Do not commit the keystore. A typical `keystore.properties` (gitignored) is:

```
storeFile=/absolute/path/jarvis.jks
storePassword=...
keyAlias=jarvis
keyPassword=...
```

3. In Android Studio choose **Android App Bundle** for Play, or **APK** for sideload.
4. Release `BuildConfig` API key fields are empty on purpose.

## Tests

Unit tests cover:

- malformed Gemini payloads
- function-call parsing
- model attempts to set `confirmed` / `force` / `bypass`
- shell and install-style tools rejected
- safety classification
- emergency numbers
- local command parsing
- session timeout
- coordinator confirmation flow (gateway is not called until the user says yes)
- blocked actions never reaching the executor gateway
- ViewModel submit / listen / stop

There is no instrumented device test in this environment. Run those on a phone or emulator if you want UI tests.

## Known Android limitations

These are platform rules, not missing code.

- **Wake word is not magic.** Continuous listening requires a foreground service, a notification you can see, and the microphone indicator. OEMs may still kill it. There is a switch to turn it off. Audio is not written to a file.
- **This app cannot be the system "Hey Google" hotword** without being a privileged assistant. The supported always-available triggers are the overlay, the notification, and (if you want it later) the user choosing a default assistant. A full `VoiceInteractionService` is not required for the flows implemented here.
- **Reboot.** `BOOT_COMPLETED` reschedules alarms and, only if you opted in, starts the foreground service. Android 12+ can still refuse a background foreground-service start. If that happens, the failure is logged and you open the app once.
- **Calls.** Default behavior opens the dialer after you confirm. The app will not dial emergency or star/hash codes. Direct calling is an explicit setting and still asks first.
- **Messages.** JARVIS opens a draft in SMS or WhatsApp. It does not call `SmsManager.sendTextMessage`. You press send.
- **Alarms.** `AlarmClock` intents keep the clock UI (`EXTRA_SKIP_UI` is false).
- **Media keys** are a request to the current session. Some phones ignore them unless a player is already active. Say the app name ("play Spotify") to open it.
- **Screen context** uses an accessibility service you enable yourself. It does not click, type, or fill passwords. Password nodes are skipped. Turn the in-app switch off to stop processing immediately; disable the service in system settings to remove the capability entirely. Do not use it on banking screens.
- **Notifications** are summarized only after you grant notification access, and you can exclude packages. The inbox is in memory only.
- **Schedule** needs calendar permission and only reads today's events.
- **Exact alarms** need the special app access on Android 12+. Otherwise alarms are inexact.
- **Overlay** cannot appear until `Settings.canDrawOverlays` is true.
- **No root, no shell, no silent install, no purchase confirmation, no lock-screen bypass.**

## Privacy

- No microphone audio is stored.
- Keys are not printed. Logs pass through `LogRedactor`.
- Screen text and notification text are not written to Room.
- Memories are rows you can see and delete.
- Backup of the secret store and settings file is excluded.
- Release builds do not embed developer keys.

## Logging tags

`JARVIS_AI`, `JARVIS_VOICE`, `JARVIS_ACTION`, `JARVIS_SERVICE`, `JARVIS_PERMISSION`

Export them from Settings → Developer. Message bodies and keys are not supposed to be in those lines; action logs record the tool name, not the SMS text.
