/**
 * Minimal Gemini proxy. The API key stays here, not in the Android app.
 *
 *   GEMINI_API_KEY=your_key node server.mjs
 *
 * Listens on 0.0.0.0:8787
 * POST /v1/gemini   { "model": "gemini-2.5-flash", "request": { ...generateContent body... } }
 */
import http from "node:http";

const key = process.env.GEMINI_API_KEY || "";
const port = Number(process.env.PORT || 8787);

function send(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, {
    "content-type": "application/json",
    "access-control-allow-origin": "*",
  });
  res.end(data);
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "content-type",
      "access-control-allow-methods": "POST, OPTIONS",
    });
    res.end();
    return;
  }
  if (req.method !== "POST" || req.url !== "/v1/gemini") {
    send(res, 404, { error: "Use POST /v1/gemini" });
    return;
  }
  if (!key) {
    send(res, 500, { error: "GEMINI_API_KEY is not set on the proxy." });
    return;
  }
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  let payload;
  try {
    payload = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    send(res, 400, { error: "Invalid JSON" });
    return;
  }
  const model = String(payload.model || "gemini-2.5-flash");
  if (!/^[\w.\-]+$/.test(model)) {
    send(res, 400, { error: "Invalid model id" });
    return;
  }
  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) +
    ":generateContent";
  try {
    const upstream = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-goog-api-key": key,
      },
      body: JSON.stringify(payload.request || {}),
    });
    const text = await upstream.text();
    res.writeHead(upstream.status, { "content-type": "application/json" });
    res.end(text);
  } catch (err) {
    send(res, 502, { error: "Upstream Gemini request failed." });
  }
});

server.listen(port, "0.0.0.0", () => {
  console.log("JARVIS Gemini proxy on " + port);
});
