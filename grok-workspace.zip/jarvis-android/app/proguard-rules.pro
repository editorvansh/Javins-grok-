# Keep Room and kotlinx.serialization models used via reflection.
-keep class com.jarvis.assistant.data.db.** { *; }
-keepclassmembers class kotlinx.serialization.json.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
