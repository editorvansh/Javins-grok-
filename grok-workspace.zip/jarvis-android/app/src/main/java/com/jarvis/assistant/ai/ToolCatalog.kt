package com.jarvis.assistant.ai

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

data class ToolSpec(
    val name: String,
    val description: String,
    val parameters: JsonObject,
)

object ToolCatalog {
    val tools: List<ToolSpec> = listOf(
        tool("open_app", "Open an installed app by its spoken name.", stringProps("app_name" to "App name, such as YouTube"), listOf("app_name")),
        tool("search_web", "Search the web in the browser.", stringProps("query" to "Search query"), listOf("query")),
        tool("open_url", "Open an http or https URL.", stringProps("url" to "Full http(s) URL"), listOf("url")),
        tool("call_contact", "Prepare a phone call to a saved contact. The app will ask the user to confirm.", stringProps("name" to "Contact name"), listOf("name")),
        tool("show_dialer", "Open the phone dialer with a contact or number. Does not place the call.", stringProps("target" to "Name or number"), listOf("target")),
        tool(
            "send_message_draft",
            "Open a message draft. Does not send it silently.",
            stringProps(
                "recipient" to "Contact name",
                "body" to "Message text",
                "channel" to "sms, whatsapp, or generic",
            ),
            listOf("recipient", "body"),
        ),
        tool(
            "set_alarm",
            "Open the clock app to set an alarm. Do not skip the clock UI.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("hour", intProp("Hour 0-23"))
                        put("minute", intProp("Minute 0-59"))
                        put("label", stringProp("Optional label"))
                    },
                )
                put("required", JsonArray(listOf(JsonPrimitive("hour"), JsonPrimitive("minute"))))
            },
            emptyList(),
        ),
        tool(
            "set_timer",
            "Open the clock app to set a timer.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("seconds", intProp("Duration in seconds"))
                        put("label", stringProp("Optional label"))
                    },
                )
                put("required", JsonArray(listOf(JsonPrimitive("seconds"))))
            },
            emptyList(),
        ),
        tool(
            "create_calendar_event",
            "Open a calendar event draft for the user to save.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("title", stringProp("Event title"))
                        put("start_epoch_ms", intProp("Start time unix millis"))
                        put("end_epoch_ms", intProp("End time unix millis"))
                    },
                )
                put("required", JsonArray(listOf(JsonPrimitive("title"))))
            },
            emptyList(),
        ),
        tool(
            "create_reminder",
            "Schedule a local reminder notification on this phone.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("message", stringProp("Reminder text"))
                        put("trigger_epoch_ms", intProp("When to remind, unix millis"))
                    },
                )
                put("required", JsonArray(listOf(JsonPrimitive("message"))))
            },
            emptyList(),
        ),
        tool("open_camera", "Open the camera app.", emptyObj(), emptyList()),
        tool("toggle_flashlight", "Turn the flashlight on or off.", stringProps("state" to "on, off, or toggle"), emptyList()),
        tool("open_maps", "Open the maps app.", stringProps("query" to "Optional place"), emptyList()),
        tool("navigate_to", "Open turn-by-turn navigation to a place.", stringProps("place" to "Destination"), listOf("place")),
        tool("play_media", "Send a play media key, or open a named music app.", stringProps("target" to "Optional app name"), emptyList()),
        tool("pause_media", "Send a pause media key.", emptyObj(), emptyList()),
        tool(
            "change_volume",
            "Adjust media volume.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("direction", stringProp("up, down, or mute"))
                        put("level", intProp("Optional 0-100"))
                    },
                )
            },
            emptyList(),
        ),
        tool("launch_settings", "Open a supported Android settings screen.", stringProps("panel" to "wifi, bluetooth, display, sound, apps, battery, location, accessibility, notifications, or general"), emptyList()),
        tool("read_notifications", "Summarize notifications the user allowed JARVIS to see.", emptyObj(), emptyList()),
        tool("get_battery_status", "Read the current battery percentage.", emptyObj(), emptyList()),
        tool("get_current_time", "Read the current local time.", emptyObj(), emptyList()),
        tool("get_device_information", "Read manufacturer, model, and Android version. No identifiers.", emptyObj(), emptyList()),
        tool("get_schedule", "Read today's calendar events if the user granted calendar access.", emptyObj(), emptyList()),
        tool("read_screen", "Describe on-screen text only after the user confirms and has enabled screen context.", emptyObj(), emptyList()),
        tool("remember_fact", "Store a visible memory the user can edit or delete.", stringProps("fact" to "What to remember"), listOf("fact")),
        tool(
            "forget_memory",
            "Forget a memory. Always requires user confirmation in the app.",
            buildJsonObject {
                put("type", "object")
                put(
                    "properties",
                    buildJsonObject {
                        put("query", stringProp("Text to match"))
                        put("delete_all", JsonObject(mapOf("type" to JsonPrimitive("boolean"))))
                    },
                )
            },
            emptyList(),
        ),
    )

    val names: Set<String> = tools.map { it.name }.toSet()

    fun declarationsJson(): JsonArray = JsonArray(
        tools.map { spec ->
            buildJsonObject {
                put("name", spec.name)
                put("description", spec.description)
                put("parameters", spec.parameters)
            }
        },
    )

    private fun tool(name: String, description: String, parameters: JsonObject, @Suppress("UNUSED_PARAMETER") required: List<String>) =
        ToolSpec(name, description, parameters)

    private fun emptyObj() = buildJsonObject {
        put("type", "object")
        put("properties", buildJsonObject { })
    }

    private fun stringProp(description: String) = buildJsonObject {
        put("type", "string")
        put("description", description)
    }

    private fun intProp(description: String) = buildJsonObject {
        put("type", "integer")
        put("description", description)
    }

    private fun stringProps(vararg fields: Pair<String, String>, required: List<String> = emptyList()): JsonObject =
        buildJsonObject {
            put("type", "object")
            put(
                "properties",
                buildJsonObject {
                    fields.forEach { (name, desc) -> put(name, stringProp(desc)) }
                },
            )
            if (required.isNotEmpty()) {
                put("required", JsonArray(required.map { JsonPrimitive(it) }))
            }
        }
}
