package com.jarvis.assistant.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.jarvis.assistant.domain.model.AssistantConfig
import com.jarvis.assistant.domain.model.Personality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "jarvis_settings")

data class AssistantSettings(
    val assistantName: String = "Jarvis",
    val languageTag: String = "en-US",
    val personality: Personality = Personality.FRIENDLY,
    val timeoutSec: Int = 30,
    val theme: String = "midnight",
    val geminiModel: String = "gemini-2.5-flash",
    val proxyUrl: String = "",
    val voiceId: String = "21m00Tcm4TlvDq8ikWAM",
    val speechRate: Float = 1.0f,
    val wakeEnabled: Boolean = false,
    val overlayEnabled: Boolean = false,
    val overlayScale: Float = 1f,
    val startOnBoot: Boolean = false,
    val memoryEnabled: Boolean = true,
    val screenContextEnabled: Boolean = false,
    val notificationSummaryEnabled: Boolean = false,
    val directCalling: Boolean = false,
    val excludedPackages: Set<String> = emptySet(),
    val onboardingDone: Boolean = false,
    val debugLogs: Boolean = false,
) {
    fun toConfig() = AssistantConfig(
        assistantName = assistantName.ifBlank { "Jarvis" },
        personality = personality,
        timeoutMs = timeoutSec.coerceIn(10, 300) * 1000L,
        memoryEnabled = memoryEnabled,
    )
}

class SettingsRepository(private val context: Context) {
    val flow: Flow<AssistantSettings> = context.settingsDataStore.data.map { it.toSettings() }

    suspend fun snapshot(): AssistantSettings = flow.first()

    suspend fun update(transform: (AssistantSettings) -> AssistantSettings) {
        val current = snapshot()
        val next = transform(current)
        context.settingsDataStore.edit { prefs -> prefs.write(next) }
    }

    private fun Preferences.toSettings() = AssistantSettings(
        assistantName = this[Keys.name] ?: "Jarvis",
        languageTag = this[Keys.language] ?: "en-US",
        personality = Personality.fromId(this[Keys.personality] ?: Personality.FRIENDLY.id),
        timeoutSec = this[Keys.timeout] ?: 30,
        theme = this[Keys.theme] ?: "midnight",
        geminiModel = this[Keys.model] ?: "gemini-2.5-flash",
        proxyUrl = this[Keys.proxy] ?: "",
        voiceId = this[Keys.voiceId] ?: "21m00Tcm4TlvDq8ikWAM",
        speechRate = this[Keys.rate] ?: 1f,
        wakeEnabled = this[Keys.wake] ?: false,
        overlayEnabled = this[Keys.overlay] ?: false,
        overlayScale = this[Keys.overlayScale] ?: 1f,
        startOnBoot = this[Keys.boot] ?: false,
        memoryEnabled = this[Keys.memory] ?: true,
        screenContextEnabled = this[Keys.screen] ?: false,
        notificationSummaryEnabled = this[Keys.notifications] ?: false,
        directCalling = this[Keys.directCall] ?: false,
        excludedPackages = this[Keys.excluded] ?: emptySet(),
        onboardingDone = this[Keys.onboarding] ?: false,
        debugLogs = this[Keys.debug] ?: false,
    )

    private fun MutablePreferences.write(settings: AssistantSettings) {
        this[Keys.name] = settings.assistantName
        this[Keys.language] = settings.languageTag
        this[Keys.personality] = settings.personality.id
        this[Keys.timeout] = settings.timeoutSec
        this[Keys.theme] = settings.theme
        this[Keys.model] = settings.geminiModel
        this[Keys.proxy] = settings.proxyUrl
        this[Keys.voiceId] = settings.voiceId
        this[Keys.rate] = settings.speechRate
        this[Keys.wake] = settings.wakeEnabled
        this[Keys.overlay] = settings.overlayEnabled
        this[Keys.overlayScale] = settings.overlayScale
        this[Keys.boot] = settings.startOnBoot
        this[Keys.memory] = settings.memoryEnabled
        this[Keys.screen] = settings.screenContextEnabled
        this[Keys.notifications] = settings.notificationSummaryEnabled
        this[Keys.directCall] = settings.directCalling
        this[Keys.excluded] = settings.excludedPackages
        this[Keys.onboarding] = settings.onboardingDone
        this[Keys.debug] = settings.debugLogs
    }

    private object Keys {
        val name = stringPreferencesKey("assistant_name")
        val language = stringPreferencesKey("language")
        val personality = stringPreferencesKey("personality")
        val timeout = intPreferencesKey("timeout_sec")
        val theme = stringPreferencesKey("theme")
        val model = stringPreferencesKey("gemini_model")
        val proxy = stringPreferencesKey("proxy_url")
        val voiceId = stringPreferencesKey("voice_id")
        val rate = floatPreferencesKey("speech_rate")
        val wake = booleanPreferencesKey("wake")
        val overlay = booleanPreferencesKey("overlay")
        val overlayScale = floatPreferencesKey("overlay_scale")
        val boot = booleanPreferencesKey("boot")
        val memory = booleanPreferencesKey("memory")
        val screen = booleanPreferencesKey("screen")
        val notifications = booleanPreferencesKey("notifications")
        val directCall = booleanPreferencesKey("direct_call")
        val excluded = stringSetPreferencesKey("excluded_packages")
        val onboarding = booleanPreferencesKey("onboarding_done")
        val debug = booleanPreferencesKey("debug_logs")
    }
}
