package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.assistant.logging.JarvisLogger
import com.jarvis.assistant.logging.JarvisTags

class VoiceRecognitionManager(
    private val context: Context,
    private val logger: JarvisLogger,
    private val onPartial: (String) -> Unit,
    private val onAmplitude: (Float) -> Unit,
    private val onResult: (String) -> Unit,
    private val onError: (String) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null
    private var shouldRestart = false

    fun start(languageTag: String, restart: Boolean) {
        shouldRestart = restart
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition isn't available on this phone.")
            return
        }
        val active = recognizer ?: SpeechRecognizer.createSpeechRecognizer(context).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag.ifBlank { "en-US" })
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
        try {
            active.startListening(intent)
            logger.d(JarvisTags.VOICE, "Listening started")
        } catch (e: Exception) {
            logger.e(JarvisTags.VOICE, "Unable to start listening", e)
            onError("I couldn't start the microphone.")
        }
    }

    fun stop() {
        shouldRestart = false
        try {
            recognizer?.stopListening()
        } catch (_: Exception) {
        }
    }

    fun destroy() {
        shouldRestart = false
        recognizer?.destroy()
        recognizer = null
    }

    fun wantsRestart(): Boolean = shouldRestart

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            onAmplitude(normalized)
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit

        override fun onError(error: Int) {
            onAmplitude(0f)
            val message = when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech recognition needs a network connection on this device."
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ""
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The microphone is busy. Try again."
                SpeechRecognizer.ERROR_AUDIO -> "The microphone isn't available."
                else -> ""
            }
            if (message.isNotBlank()) {
                logger.e(JarvisTags.VOICE, "Speech error $error")
                onError(message)
            } else if (shouldRestart) {
                onResult("")
            }
        }

        override fun onResults(results: Bundle?) {
            onAmplitude(0f)
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            onResult(text)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isNotBlank()) onPartial(text)
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }
}
