package com.jarvis.assistant.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.logging.JarvisTags
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class JarvisForegroundService : Service() {
    private val job = SupervisorJob()
    private val scope = CoroutineScope(job + Dispatchers.Main.immediate)
    private var overlay: OrbOverlayView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val app = application as JarvisApplication
        scope.launch {
            app.container.engine.phase.collect { phase -> overlay?.setPhase(phase) }
        }
        scope.launch {
            app.container.engine.amplitude.collect { overlay?.setAmplitude(it) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as JarvisApplication
        if (intent?.action == ACTION_STOP) {
            app.container.engine.stop()
            removeOverlay()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val settings = app.container.settingsCached
        val notification = buildNotification(settings.wakeEnabled, settings.assistantName)
        val type = if (settings.wakeEnabled) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
        } catch (e: Exception) {
            app.container.logger.e(JarvisTags.SERVICE, "Foreground start blocked", e)
            stopSelf()
            return START_NOT_STICKY
        }
        if (settings.overlayEnabled && Settings.canDrawOverlays(this)) {
            showOverlay(app)
        } else {
            removeOverlay()
        }
        app.container.engine.applyBackgroundMode(settings.wakeEnabled)
        return START_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        scope.cancel()
        super.onDestroy()
    }

    private fun showOverlay(app: JarvisApplication) {
        if (overlay != null) return
        val wm = getSystemService(WindowManager::class.java)
        val view = OrbOverlayView(this)
        val layout = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 24
            y = 0
        }
        view.setOnTouchListener(object : android.view.View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            override fun onTouch(v: android.view.View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        startX = layout.x
                        startY = layout.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layout.x = startX - (event.rawX - downX).toInt()
                        layout.y = startY + (event.rawY - downY).toInt()
                        wm.updateViewLayout(view, layout)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = kotlin.math.abs(event.rawX - downX)
                        val dy = kotlin.math.abs(event.rawY - downY)
                        if (dx < 12 && dy < 12) app.container.engine.toggleListen()
                        return true
                    }
                }
                return false
            }
        })
        try {
            wm.addView(view, layout)
            overlay = view
            params = layout
        } catch (e: Exception) {
            app.container.logger.e(JarvisTags.SERVICE, "Overlay was not added", e)
        }
    }

    private fun removeOverlay() {
        val view = overlay ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(view)
        } catch (_: Exception) {
        }
        overlay = null
    }

    private fun buildNotification(listening: Boolean, name: String): Notification {
        val open = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this,
            2,
            Intent(this, JarvisForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = if (listening) {
            "$name is listening for its name. The microphone indicator stays on until you stop it."
        } else {
            "$name overlay is available. Tap stop to dismiss it."
        }
        return NotificationCompat.Builder(this, CHANNEL_STATUS)
            .setSmallIcon(R.drawable.ic_stat_orb)
            .setContentTitle(name)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(R.drawable.ic_stat_orb, "Stop", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val CHANNEL_STATUS = "jarvis_status"
        const val CHANNEL_ALERTS = "jarvis_alerts"
        const val NOTIFICATION_ID = 42
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val ACTION_SYNC = "com.jarvis.assistant.SYNC"

        fun ensureChannels(context: Context) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val status = NotificationChannel(
                CHANNEL_STATUS,
                "Assistant status",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Shown while JARVIS is listening or showing the overlay."
            }
            val alerts = NotificationChannel(
                CHANNEL_ALERTS,
                "Reminders",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply { description = "Reminders and automations you created." }
            manager.createNotificationChannel(status)
            manager.createNotificationChannel(alerts)
        }

        fun start(context: Context, action: String = ACTION_START) {
            val intent = Intent(context, JarvisForegroundService::class.java).setAction(action)
            try {
                androidx.core.content.ContextCompat.startForegroundService(context, intent)
            } catch (e: Exception) {
                val app = context.applicationContext as? JarvisApplication
                app?.container?.logger?.e(JarvisTags.SERVICE, "Could not start assistant service", e)
            }
        }
    }
}
