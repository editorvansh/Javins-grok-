package com.jarvis.assistant.data.net

data class HttpResult(
    val code: Int,
    val body: String,
    val error: String? = null,
)

interface HttpTransport {
    suspend fun post(
        url: String,
        headers: Map<String, String>,
        jsonBody: String,
        timeoutMs: Long = 30_000L,
    ): HttpResult
}
