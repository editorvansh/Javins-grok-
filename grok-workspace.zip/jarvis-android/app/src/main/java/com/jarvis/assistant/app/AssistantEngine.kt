package com.jarvis.assistant.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import com.jarvis.assistant.ai.Utterance
import com.jarvis.assistant.data.db.HistoryRepository
import com.jarvis.assistant.data.prefs.SettingsRepository
import com.jarvis.assistant.domain.model.AssistantCoordinator
import com.jarvis.assistant.domain.model.AssistantPhase
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.logging.JarvisLogger
import com.jarvis.assistant.logging.JarvisTags
import com.jarvis.assistant.voice.VoiceRecognitionManager
import com.jarvis.assistant.voice.VoiceSpeaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

interface AssistantEngine {
    val phase: StateFlow<AssistantPhase>
    val messages: StateFlow<List<ChatMessage>>
    val partial: StateFlow<String>
    val amplitude: StateFlow<Float>
    val pendingPrompt: StateFlow<String?>
    val error: StateFlow<String?>
    val statusLine: StateFlow<String>
    fun submit(text: String)
    fun toggleListen()
    fun stop()
}

class AssistantEngineImpl(
    private val context: Context,
    private val scope: CoroutineScope,
    private val coordinator: AssistantCoordinator,
    private val speaker: VoiceSpeaker,
    private val recognizer: VoiceRecognitionManager,
    private val settings: SettingsRepository,
    private val history: HistoryRepository,
    private val logger: JarvisLogger,
) : AssistantEngine {
    override val phase = MutableStateFlow(AssistantPhase.IDLE)
    override val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    override val partial = MutableStateFlow("")
    override val amplitude = MutableStateFlow(0f)
    override val pendingPrompt = MutableStateFlow<String?>(null)
    override val error = MutableStateFlow<String?>(null)
    override val statusLine = MutableStateFlow("Ready")

    private val mutex = Mutex()
    private var manual = false
    private var wake = false
    private var paused = false
    private var wakeApplied = false

    fun onPartial(text: String) {
        partial.value = text
    }

    fun onAmplitude(value: Float) {
        amplitude.value = value
    }

    fun onHeard(text: String) {
        scope.launch { handleHeard(text) }
    }

    fun onListenError(message: String) {
        if (message.isBlank()) return
        error.value = message
        phase.value = AssistantPhase.ERROR
        statusLine.value = message
        logger.e(JarvisTags.VOICE, message)
    }

    override fun submit(text: String) {
        scope.launch { submitAndWait(text) }
    }

    suspend fun submitAndWait(text: String) {
        mutex.withLock {
            error.value = null
            partial.value = ""
            phase.value = AssistantPhase.THINKING
            statusLine.value = "Thinking"
            val before = coordinator.messages().size
            val result = coordinator.handleText(text)
            result.messages.drop(before).forEach { history.append(it) }
            messages.value = result.messages
            pendingPrompt.value = result.pendingPrompt
            error.value = result.error
            phase.value = AssistantPhase.SPEAKING
            statusLine.value = "Speaking"
            speaker.speak(result.spokenText)
            phase.value = if (result.error != null) AssistantPhase.ERROR else AssistantPhase.IDLE
            statusLine.value = result.pendingPrompt ?: if (result.error != null) "Needs attention" else "Ready"
        }
    }

    suspend fun speakOut(text: String) {
        phase.value = AssistantPhase.SPEAKING
        speaker.speak(text)
        if (phase.value == AssistantPhase.SPEAKING) phase.value = AssistantPhase.IDLE
    }

    override fun toggleListen() {
        scope.launch {
            if (manual && phase.value == AssistantPhase.LISTENING) {
                manual = false
                withContext(Dispatchers.Main) { recognizer.stop() }
                phase.value = AssistantPhase.IDLE
                statusLine.value = "Ready"
                amplitude.value = 0f
                return@launch
            }
            if (!hasMic()) {
                error.value = "Microphone permission is needed for voice. You can still type."
                phase.value = AssistantPhase.ERROR
                return@launch
            }
            paused = false
            manual = true
            error.value = null
            phase.value = AssistantPhase.LISTENING
            statusLine.value = "Listening"
            val language = settings.snapshot().languageTag
            withContext(Dispatchers.Main) { recognizer.start(language, restart = false) }
        }
    }

    fun applyBackgroundMode(enabled: Boolean) {
        if (wakeApplied == enabled) return
        wakeApplied = enabled
        wake = enabled
        if (!enabled) {
            if (!manual) {
                scope.launch(Dispatchers.Main) { recognizer.stop() }
                if (phase.value == AssistantPhase.LISTENING) {
                    phase.value = AssistantPhase.IDLE
                    statusLine.value = "Ready"
                }
            }
            return
        }
        paused = false
        restartWake()
    }

    override fun stop() {
        paused = true
        manual = false
        scope.launch(Dispatchers.Main) { recognizer.stop() }
        speaker.stop()
        coordinator.endSession()
        amplitude.value = 0f
        partial.value = ""
        phase.value = AssistantPhase.IDLE
        statusLine.value = "Stopped"
    }

    private suspend fun handleHeard(text: String) {
        if (text.isBlank()) {
            if (wake && !paused && !manual) restartWake()
            return
        }
        val prefs = settings.snapshot()
        if (!manual && wake) {
            val session = coordinator.isSessionActive()
            if (!session && !Utterance.containsWake(text, prefs.assistantName)) {
                restartWake()
                return
            }
        }
        manual = false
        submitAndWait(text)
        if (wake && !paused) restartWake()
    }

    private fun restartWake() {
        scope.launch {
            delay(450)
            if (!wake || paused || manual) return@launch
            if (!hasMic()) {
                error.value = "Wake listening needs microphone permission."
                phase.value = AssistantPhase.ERROR
                return@launch
            }
            val prefs = settings.snapshot()
            phase.value = AssistantPhase.LISTENING
            statusLine.value = "Listening for ${prefs.assistantName}"
            withContext(Dispatchers.Main) {
                recognizer.start(prefs.languageTag, restart = true)
            }
        }
    }

    private fun hasMic(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}
