package com.jarvis.assistant.ai

import com.jarvis.assistant.data.net.HttpTransport
import com.jarvis.assistant.domain.model.BrainResult
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.GeminiBrain
import com.jarvis.assistant.domain.model.PlanRequest
import com.jarvis.assistant.logging.JarvisLogger
import com.jarvis.assistant.logging.JarvisTags
import com.jarvis.assistant.logging.LogRedactor
import com.jarvis.assistant.logging.NoopLogger
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

data class GeminiCredentials(
    val apiKey: String = "",
    val proxyUrl: String = "",
    val model: String = "gemini-2.5-flash",
)

/**
 * Calls the official Gemini generateContent REST API, or a user-configured proxy.
 * Direct keys are for a personal sideload. Shipping a store build should use [proxyUrl].
 */
class GeminiRepository(
    private val http: HttpTransport,
    private val credentials: () -> GeminiCredentials,
    private val logger: JarvisLogger = NoopLogger,
) : GeminiBrain {

    override suspend fun plan(request: PlanRequest): BrainResult {
        val creds = credentials()
        val model = creds.model.ifBlank { "gemini-2.5-flash" }
        if (!model.matches(Regex("[A-Za-z0-9.\\-_]+"))) {
            return BrainResult(null, emptyList(), "That Gemini model id doesn't look valid.")
        }
        val body = requestBody(request)
        val proxy = creds.proxyUrl.trim().trimEnd('/')
        val directKey = creds.apiKey.trim()
        if (proxy.isEmpty() && directKey.isEmpty()) {
            return BrainResult(
                text = null,
                actions = emptyList(),
                failure = "Gemini isn't configured yet. Add an API key or a proxy URL in Settings.",
            )
        }
        val (url, payload, headers) = if (proxy.isNotEmpty()) {
            val wrapped = buildJsonObject {
                put("model", model)
                put("request", body)
            }.toString()
            Triple(proxy + "/v1/gemini", wrapped, mapOf("Content-Type" to "application/json"))
        } else {
            Triple(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                body.toString(),
                mapOf(
                    "Content-Type" to "application/json",
                    "x-goog-api-key" to directKey,
                ),
            )
        }
        logger.d(JarvisTags.AI, "Gemini request model=$model via=${if (proxy.isNotEmpty()) "proxy" else "direct"}")
        val response = http.post(url, headers, payload)
        if (response.error != null || response.code == 0) {
            logger.e(JarvisTags.AI, "Gemini network failure")
            return BrainResult(null, emptyList(), "I can't reach Gemini right now. Check your connection.")
        }
        if (response.code == 401 || response.code == 403) {
            return BrainResult(null, emptyList(), "The Gemini key was rejected. Check it in Settings.")
        }
        if (response.code == 429) {
            return BrainResult(null, emptyList(), "Gemini is rate limiting requests. Give it a moment and try again.")
        }
        if (response.code !in 200..299) {
            logger.e(JarvisTags.AI, "Gemini HTTP ${response.code} ${LogRedactor.redact(response.body.take(180))}")
            return BrainResult(null, emptyList(), "Gemini returned an error (${response.code}). Try again in a moment.")
        }
        val parsed = GeminiResponseParser.parse(response.body)
        if (parsed.text == null && parsed.actions.isEmpty()) {
            val loose = request.userText
            logger.d(JarvisTags.AI, "Empty Gemini payload for utterance length=${loose.length}")
        }
        return BrainResult(parsed.text, parsed.actions, failure = null)
    }

    private fun requestBody(request: PlanRequest) = buildJsonObject {
        put(
            "system_instruction",
            buildJsonObject {
                put(
                    "parts",
                    buildJsonArray {
                        add(buildJsonObject {
                            put("text", SystemPrompts.build(request.assistantName, request.personality, request.memoryLines))
                        })
                    },
                )
            },
        )
        put("contents", historyJson(request))
        if (request.useTools) {
            put(
                "tools",
                buildJsonArray {
                    add(buildJsonObject { put("functionDeclarations", ToolCatalog.declarationsJson()) })
                },
            )
            put(
                "toolConfig",
                buildJsonObject {
                    put("functionCallingConfig", buildJsonObject { put("mode", "AUTO") })
                },
            )
        }
        put(
            "generationConfig",
            buildJsonObject {
                put("temperature", 0.6)
                put("maxOutputTokens", 700)
            },
        )
    }

    private fun historyJson(request: PlanRequest): JsonArray = buildJsonArray {
        request.history.filter { it.role != ChatMessage.Role.SYSTEM }.takeLast(10).forEach { message ->
            add(
                buildJsonObject {
                    put("role", if (message.role == ChatMessage.Role.USER) "user" else "model")
                    put("parts", buildJsonArray { add(buildJsonObject { put("text", message.text.take(2000)) }) })
                },
            )
        }
        add(
            buildJsonObject {
                put("role", "user")
                put("parts", buildJsonArray { add(buildJsonObject { put("text", request.userText.take(2000)) }) })
            },
        )
    }
}
