package com.jarvis.assistant.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.actions.NotificationInbox
import com.jarvis.assistant.actions.InboxNote
import com.jarvis.assistant.actions.ScreenContextStore
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads on-screen text only while the in-app screen-context switch is on.
 * Does not click, type, or bypass permissions. Skips password fields.
 */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val app = applicationContext as? JarvisApplication ?: return
        val enabled = app.container.settingsCached.screenContextEnabled
        ScreenContextStore.enabled = enabled
        if (!enabled) {
            ScreenContextStore.clear()
            return
        }
        val root = rootInActiveWindow ?: return
        val excluded = app.container.settingsCached.excludedPackages
        val pkg = event?.packageName?.toString().orEmpty()
        if (pkg.isNotBlank() && pkg in excluded) {
            ScreenContextStore.clear()
            return
        }
        val lines = LinkedHashSet<String>()
        collect(root, lines, 0)
        ScreenContextStore.packageName = pkg
        ScreenContextStore.text = lines.take(40).joinToString("\n")
    }

    override fun onInterrupt() {
        ScreenContextStore.clear()
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (node == null || depth > 14 || out.size > 40) return
        if (node.isPassword) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (text.length in 2..180) out += text
        else if (desc.length in 2..120) out += desc
        for (i in 0 until node.childCount) {
            collect(node.getChild(i), out, depth + 1)
        }
    }
}

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notice = sbn ?: return
        val app = applicationContext as? JarvisApplication ?: return
        val settings = app.container.settingsCached
        val extras = notice.notification.extras
        val title = extras?.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras?.getCharSequence("android.text")?.toString().orEmpty()
        NotificationInbox.add(
            InboxNote(
                packageName = notice.packageName,
                title = title.take(80),
                text = text.take(140),
                postedAt = notice.postTime,
            ),
            enabled = settings.notificationSummaryEnabled,
            excluded = settings.excludedPackages + setOf(packageName),
        )
    }
}
