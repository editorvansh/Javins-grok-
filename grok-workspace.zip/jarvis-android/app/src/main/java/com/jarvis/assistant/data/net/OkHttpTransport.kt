package com.jarvis.assistant.data.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class OkHttpTransport : HttpTransport {
    private val client = OkHttpClient.Builder()
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    override suspend fun post(
        url: String,
        headers: Map<String, String>,
        jsonBody: String,
        timeoutMs: Long,
    ): HttpResult = withContext(Dispatchers.IO) {
        try {
            val builder = Request.Builder().url(url).post(jsonBody.toRequestBody("application/json".toMediaType()))
            headers.forEach { (key, value) -> builder.header(key, value) }
            client.newCall(builder.build()).execute().use { response ->
                HttpResult(code = response.code, body = response.body?.string().orEmpty())
            }
        } catch (e: Exception) {
            HttpResult(code = 0, body = "", error = e.javaClass.simpleName)
        }
    }
}
