package com.jarvis.assistant.ai

object Utterance {
    fun normalize(raw: String): String =
        raw.trim()
            .replace(Regex("[“”]"), "\"")
            .replace(Regex("\\s+"), " ")

    fun stripWake(raw: String, assistantName: String): String {
        var text = normalize(raw)
        val name = assistantName.trim().ifBlank { "jarvis" }
        val pattern = Regex("^(?:hey\\s+|ok\\s+|okay\\s+)?${Regex.escape(name)}[,\\s]*", RegexOption.IGNORE_CASE)
        text = text.replace(pattern, "").trim()
        return text.trim(' ', ',', '.', '!')
    }

    fun isWakeOnly(raw: String, assistantName: String): Boolean {
        val text = normalize(raw).trimEnd('?', '.', '!', ',')
        if (text.isEmpty()) return false
        val name = assistantName.trim().ifBlank { "jarvis" }
        val pattern = Regex("^(?:hey\\s+|ok\\s+|okay\\s+)?${Regex.escape(name)}$", RegexOption.IGNORE_CASE)
        return pattern.matches(text)
    }

    fun containsWake(raw: String, assistantName: String): Boolean {
        val name = assistantName.trim().ifBlank { "jarvis" }
        return Regex("(?i)\\b${Regex.escape(name)}\\b").containsMatchIn(raw)
    }

    private val yes = setOf(
        "yes", "yeah", "yep", "yup", "confirm", "confirmed", "do it", "send it",
        "go ahead", "sure", "ok", "okay", "please do", "yes please", "affirmative",
    )
    private val no = setOf(
        "no", "nope", "cancel", "stop", "don't", "do not", "never mind", "nevermind",
        "nah", "negative", "don't do that",
    )

    fun isAffirmative(raw: String): Boolean {
        val text = normalize(raw).lowercase().trimEnd('.', '!', '?')
        return text in yes
    }

    fun isNegative(raw: String): Boolean {
        val text = normalize(raw).lowercase().trimEnd('.', '!', '?')
        return text in no
    }
}
