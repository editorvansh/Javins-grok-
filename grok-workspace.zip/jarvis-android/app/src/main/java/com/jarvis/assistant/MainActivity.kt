package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.ui.nav.JarvisRoot
import com.jarvis.assistant.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as JarvisApplication
        setContent {
            val settings by app.container.settings.flow.collectAsState(
                initial = app.container.settingsCached,
            )
            val viewModel: JarvisViewModel = viewModel(factory = app.container.viewModelFactory())
            JarvisTheme {
                JarvisRoot(
                    container = app.container,
                    settings = settings,
                    viewModel = viewModel,
                )
            }
        }
    }
}
