package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.JarvisAction
import java.util.Calendar
import java.util.Locale

/**
 * Offline fallback for clear device commands. High precision, low recall.
 * Anything uncertain returns null so conversation is not hijacked.
 */
class LocalCommandParser(
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    fun parse(raw: String): JarvisAction? {
        val text = Utterance.normalize(raw).trim().trimEnd('.', '!', '?')
        if (text.isEmpty()) return null
        val lower = text.lowercase(Locale.US)

        parseAlarm(lower)?.let { return it }
        parseTimer(lower)?.let { return it }

        when {
            lower == "what time is it" || lower == "what's the time" || lower == "whats the time" ||
                lower == "current time" || lower == "what time" -> return JarvisAction.GetCurrentTime
            lower.contains("battery") && (lower.startsWith("battery") || lower.startsWith("what's") || lower.startsWith("whats") || lower.startsWith("how much") || lower.startsWith("check")) ->
                return JarvisAction.GetBatteryStatus
            lower.contains("on my screen") || lower.contains("on the screen") || lower == "what's on screen" ->
                return JarvisAction.ReadScreen
            lower.contains("notification") || lower == "what did i miss" || lower == "what did i miss today" ->
                return JarvisAction.ReadNotifications
            lower == "device info" || lower == "what phone is this" || lower.contains("device information") ->
                return JarvisAction.GetDeviceInformation
            lower.contains("my schedule") || lower.contains("my calendar") || lower == "what's on today" || lower == "whats on today" ->
                return JarvisAction.GetSchedule
            lower == "open camera" || lower == "take a photo" || lower == "open the camera" ->
                return JarvisAction.OpenCamera
            lower == "flashlight on" || lower == "turn on the flashlight" || lower == "torch on" || lower == "turn on flashlight" ->
                return JarvisAction.ToggleFlashlight(true)
            lower == "flashlight off" || lower == "turn off the flashlight" || lower == "torch off" || lower == "turn off flashlight" ->
                return JarvisAction.ToggleFlashlight(false)
            lower == "toggle flashlight" || lower == "toggle the flashlight" ->
                return JarvisAction.ToggleFlashlight(null)
            lower == "pause" || lower == "pause music" || lower == "stop music" ->
                return JarvisAction.PauseMedia
            lower == "play" || lower == "play music" || lower == "resume music" || lower == "resume" ->
                return JarvisAction.PlayMedia(null)
            lower == "volume up" || lower == "turn it up" || lower == "louder" ->
                return JarvisAction.ChangeVolume("up", null)
            lower == "volume down" || lower == "turn it down" || lower == "quieter" ->
                return JarvisAction.ChangeVolume("down", null)
            lower == "mute" || lower == "mute volume" ->
                return JarvisAction.ChangeVolume("mute", 0)
            lower == "open settings" || lower == "settings" ->
                return JarvisAction.LaunchSettings("general")
        }

        SETTINGS.find(lower)?.let { match ->
            return JarvisAction.LaunchSettings(match.groupValues[1].lowercase(Locale.US))
        }
        OPEN.find(text)?.let { match ->
            val name = match.groupValues[1].trim()
            if (name.length in 2..60 && !name.equals("settings", true)) return JarvisAction.OpenApp(name)
            if (name.equals("settings", true)) return JarvisAction.LaunchSettings("general")
        }
        CALL.find(text)?.let { match ->
            val name = match.groupValues[1].trim()
            if (name.isNotBlank() && !name.startsWith("me ")) return JarvisAction.CallContact(name)
        }
        DIAL.find(text)?.let { match ->
            return JarvisAction.ShowDialer(match.groupValues[1].trim())
        }
        MESSAGE.find(text)?.let { match ->
            return JarvisAction.SendMessageDraft(
                recipient = match.groupValues[1].trim(),
                body = match.groupValues[2].trim(),
                channel = "sms",
            )
        }
        NAVIGATE.find(text)?.let { match ->
            return JarvisAction.NavigateTo(match.groupValues[1].trim())
        }
        SEARCH.find(text)?.let { match ->
            return JarvisAction.SearchWeb(match.groupValues[1].trim())
        }
        REMEMBER.find(text)?.let { match ->
            return JarvisAction.RememberFact(match.groupValues[1].trim())
        }
        REMIND.find(lower)?.let {
            val message = text.substringAfter("remind me", "reminder").trim()
            val trigger = if (lower.contains("tomorrow")) tomorrowMorning() else now() + 3_600_000L
            return JarvisAction.CreateReminder(message.ifBlank { "Reminder" }, trigger)
        }
        return null
    }

    private fun parseAlarm(lower: String): JarvisAction? {
        if (!lower.contains("alarm")) return null
        val match = ALARM.find(lower) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val ampm = match.groupValues[3].lowercase(Locale.US)
        if (minute !in 0..59 || hour !in 0..23) return null
        if (ampm.startsWith("p") && hour < 12) hour += 12
        if (ampm.startsWith("a") && hour == 12) hour = 0
        if (ampm.isBlank() && hour <= 12 && lower.contains("am") && hour == 12) hour = 0
        return JarvisAction.SetAlarm(hour, minute, "Alarm")
    }

    private fun parseTimer(lower: String): JarvisAction? {
        if (!lower.contains("timer")) return null
        val match = TIMER.find(lower) ?: return null
        val amount = match.groupValues[1].toIntOrNull() ?: return null
        if (amount <= 0) return null
        val unit = match.groupValues[2]
        val seconds = when {
            unit.startsWith("hour") -> amount * 3600
            unit.startsWith("min") -> amount * 60
            else -> amount
        }
        return JarvisAction.SetTimer(seconds.coerceAtMost(24 * 3600), "Timer")
    }

    private fun tomorrowMorning(): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 9)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    companion object {
        private val OPEN = Regex("^(?:please\\s+)?(?:open|launch|start)\\s+(?:the\\s+)?(?:app\\s+)?(.+)$", RegexOption.IGNORE_CASE)
        private val CALL = Regex("^(?:please\\s+)?(?:call|phone|ring)\\s+(.+)$", RegexOption.IGNORE_CASE)
        private val DIAL = Regex("^(?:please\\s+)?dial\\s+(.+)$", RegexOption.IGNORE_CASE)
        private val MESSAGE = Regex(
            "^(?:please\\s+)?(?:text|message|sms)\\s+(.+?)\\s+(?:that|saying|to say)\\s+(.+)$",
            RegexOption.IGNORE_CASE,
        )
        private val NAVIGATE = Regex("^(?:please\\s+)?(?:navigate|directions|take me)\\s+to\\s+(.+)$", RegexOption.IGNORE_CASE)
        private val SEARCH = Regex("^(?:please\\s+)?(?:search|google)\\s+(?:for\\s+)?(.+)$", RegexOption.IGNORE_CASE)
        private val REMEMBER = Regex("^(?:please\\s+)?remember\\s+(?:that\\s+)?(.+)$", RegexOption.IGNORE_CASE)
        private val REMIND = Regex("remind me\\b", RegexOption.IGNORE_CASE)
        private val ALARM = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?")
        private val TIMER = Regex("(\\d+)\\s*(seconds?|minutes?|mins?|hours?|hrs?)")
        private val SETTINGS = Regex("(?:open\\s+)?(wifi|bluetooth|display|sound|battery|location)\\s+settings")
    }
}
