package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import com.jarvis.assistant.security.SensitiveNumberGuard

data class InstalledApp(val label: String, val packageName: String)

sealed interface MatchResult<out T> {
    data class One<T>(val value: T) : MatchResult<T>
    data class Many<T>(val values: List<T>) : MatchResult<T>
    data class None(val query: String) : MatchResult<Nothing>
}

class AppController(private val context: Context) {
    fun launchers(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        return pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
            .map {
                InstalledApp(
                    label = it.loadLabel(pm)?.toString().orEmpty().ifBlank { it.activityInfo.packageName },
                    packageName = it.activityInfo.packageName,
                )
            }
            .distinctBy { it.packageName }
    }

    fun resolve(name: String): MatchResult<InstalledApp> {
        val ranked = FuzzyMatcher.rank(name, launchers(), { it.label }, threshold = 58)
        if (ranked.isEmpty()) return MatchResult.None(name)
        val top = ranked.first()
        val second = ranked.getOrNull(1)
        if (second != null && top.second < 96 && top.second - second.second < 8) {
            return MatchResult.Many(ranked.take(3).map { it.first })
        }
        return MatchResult.One(top.first)
    }

    fun open(app: InstalledApp): Boolean {
        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }
}

data class PhoneContact(val name: String, val number: String)

class ContactController(private val context: Context) {
    fun hasPermission(): Boolean =
        context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun resolve(query: String): MatchResult<PhoneContact> {
        if (!hasPermission()) return MatchResult.None(query)
        val contacts = load().distinctBy { it.number }
        val ranked = FuzzyMatcher.rank(query, contacts, { it.name }, threshold = 62)
        if (ranked.isEmpty()) {
            val digits = query.filter { it.isDigit() || it == '+' }
            if (digits.count { it.isDigit() } >= 3) {
                if (SensitiveNumberGuard.isBlocked(digits)) return MatchResult.None(query)
                return MatchResult.One(PhoneContact(query, digits))
            }
            return MatchResult.None(query)
        }
        val top = ranked.first()
        val close = ranked.filter { top.second - it.second < 8 }.map { it.first }.distinctBy { it.number }
        if (close.size > 1 && top.second < 98) return MatchResult.Many(close.take(4))
        return MatchResult.One(top.first)
    }

    private fun load(): List<PhoneContact> {
        val list = mutableListOf<PhoneContact>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
        )
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC",
        ) ?: return emptyList()
        cursor.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            var count = 0
            while (it.moveToNext() && count < 2000) {
                val name = if (nameIdx >= 0) it.getString(nameIdx).orEmpty() else ""
                val number = if (numIdx >= 0) it.getString(numIdx).orEmpty() else ""
                if (name.isNotBlank() && number.isNotBlank()) {
                    list += PhoneContact(name, number)
                    count++
                }
            }
        }
        return list
    }
}
