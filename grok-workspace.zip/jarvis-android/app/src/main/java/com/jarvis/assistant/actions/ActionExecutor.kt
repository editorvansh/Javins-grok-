package com.jarvis.assistant.actions

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import com.jarvis.assistant.data.prefs.SettingsRepository
import com.jarvis.assistant.domain.model.ActionGateway
import com.jarvis.assistant.domain.model.ActionResult
import com.jarvis.assistant.domain.model.GeminiBrain
import com.jarvis.assistant.domain.model.JarvisAction
import com.jarvis.assistant.domain.model.MemorySource
import com.jarvis.assistant.domain.model.Personality
import com.jarvis.assistant.domain.model.PlanRequest
import com.jarvis.assistant.domain.model.RiskLevel
import com.jarvis.assistant.logging.JarvisLogger
import com.jarvis.assistant.logging.JarvisTags
import com.jarvis.assistant.security.ActionSafetyManager
import com.jarvis.assistant.security.SensitiveNumberGuard
import com.jarvis.assistant.services.ReminderReceiver
import java.util.Calendar

class ActionExecutor(
    private val context: Context,
    private val safety: ActionSafetyManager,
    private val apps: AppController,
    private val contacts: ContactController,
    private val memory: MemorySource,
    private val settings: SettingsRepository,
    private val brain: GeminiBrain,
    private val logger: JarvisLogger,
) : ActionGateway {

    override suspend fun run(action: JarvisAction, confirmedByUser: Boolean): ActionResult {
        val decision = safety.classify(action)
        logger.d(JarvisTags.ACTION, "dispatch ${action::class.simpleName} risk=${decision.level} confirmed=$confirmedByUser")
        if (decision.level == RiskLevel.BLOCKED) return ActionResult.Blocked(decision.reason)
        if (decision.level == RiskLevel.CONFIRMATION_REQUIRED && !confirmedByUser) {
            return ActionResult.NeedsConfirmation(decision.prompt)
        }
        return try {
            dispatch(action)
        } catch (e: ActivityNotFoundException) {
            ActionResult.Failure("Nothing on this phone can handle that.")
        } catch (e: SecurityException) {
            logger.e(JarvisTags.ACTION, "Security exception during action", e)
            ActionResult.Failure("Android blocked that. Check the permission in Settings.")
        } catch (e: Exception) {
            logger.e(JarvisTags.ACTION, "Action failed: ${e.javaClass.simpleName}", e)
            ActionResult.Failure("I couldn't finish that. Android didn't allow it.")
        }
    }

    private suspend fun dispatch(action: JarvisAction): ActionResult = when (action) {
        is JarvisAction.OpenApp -> openApp(action.appName)
        is JarvisAction.SearchWeb -> {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", action.query)
            start(intent)
            ActionResult.Success("Searching for ${action.query}.")
        }
        is JarvisAction.OpenUrl -> openUrl(action.url)
        is JarvisAction.CallContact -> call(action.name, direct = settings.snapshot().directCalling)
        is JarvisAction.ShowDialer -> dial(action.nameOrNumber)
        is JarvisAction.SendMessageDraft -> draftMessage(action)
        is JarvisAction.SetAlarm -> setAlarm(action)
        is JarvisAction.SetTimer -> setTimer(action)
        is JarvisAction.CreateCalendarEvent -> calendar(action)
        is JarvisAction.CreateReminder -> reminder(action)
        JarvisAction.OpenCamera -> {
            start(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            ActionResult.Success("Opening the camera.")
        }
        is JarvisAction.ToggleFlashlight -> flashlight(action.enabled)
        is JarvisAction.OpenMaps -> maps(action.query)
        is JarvisAction.NavigateTo -> navigate(action.place)
        is JarvisAction.PlayMedia -> play(action.target)
        JarvisAction.PauseMedia -> {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            ActionResult.Success("Paused.")
        }
        is JarvisAction.ChangeVolume -> volume(action)
        is JarvisAction.LaunchSettings -> settingsPanel(action.panel)
        JarvisAction.ReadNotifications -> notifications()
        JarvisAction.GetBatteryStatus -> battery()
        JarvisAction.GetCurrentTime -> time()
        JarvisAction.GetDeviceInformation -> device()
        JarvisAction.GetSchedule -> schedule()
        JarvisAction.ReadScreen -> screen()
        is JarvisAction.RememberFact -> {
            if (!settings.snapshot().memoryEnabled) {
                ActionResult.Failure("Memory is turned off. You can enable it in Settings.")
            } else {
                memory.remember(action.fact)
                ActionResult.Success("I'll remember that. You can edit or delete it in Settings.")
            }
        }
        is JarvisAction.ForgetMemory -> forget(action)
        is JarvisAction.Rejected -> ActionResult.Blocked(action.detail)
    }

    private fun openApp(name: String): ActionResult = when (val match = apps.resolve(name)) {
        is MatchResult.None -> ActionResult.Failure("I couldn't find $name on this phone.")
        is MatchResult.Many -> ActionResult.Ambiguous(
            "I found ${match.values.joinToString(", ") { it.label }}. Which one?",
        )
        is MatchResult.One -> {
            if (apps.open(match.value)) ActionResult.Success("Opening ${match.value.label}.")
            else ActionResult.Failure("I found ${match.value.label}, but Android wouldn't open it.")
        }
    }

    private fun openUrl(url: String): ActionResult {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            return ActionResult.Blocked("I only open normal web links.")
        }
        start(Intent(Intent.ACTION_VIEW, uri))
        return ActionResult.Success("Opening that link.")
    }

    private fun call(name: String, direct: Boolean): ActionResult {
        if (!contacts.hasPermission()) {
            return ActionResult.Failure("I need contact permission before I can find $name.")
        }
        if (SensitiveNumberGuard.isBlocked(name)) {
            return ActionResult.Blocked("I won't call that number.")
        }
        return when (val match = contacts.resolve(name)) {
            is MatchResult.None -> ActionResult.Failure("I couldn't find a contact named $name.")
            is MatchResult.Many -> ActionResult.Ambiguous(
                "I found ${match.values.size} matches: ${match.values.joinToString(", ") { "${it.name} (${it.number})" }}. Which one?",
            )
            is MatchResult.One -> placeCall(match.value, direct)
        }
    }

    private fun dial(target: String): ActionResult {
        if (SensitiveNumberGuard.isBlocked(target)) return ActionResult.Blocked("I won't dial that number.")
        val number = if (contacts.hasPermission()) {
            when (val match = contacts.resolve(target)) {
                is MatchResult.One -> match.value.number
                is MatchResult.Many -> return ActionResult.Ambiguous(
                    "Which number? " + match.values.joinToString(", ") { "${it.name} ${it.number}" },
                )
                is MatchResult.None -> target.filter { it.isDigit() || it == '+' }
            }
        } else {
            target.filter { it.isDigit() || it == '+' }.ifBlank { target }
        }
        if (number.isBlank()) return ActionResult.Failure("I need a number or a saved contact.")
        if (SensitiveNumberGuard.isBlocked(number)) return ActionResult.Blocked("I won't dial that number.")
        start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        return ActionResult.Success("Opening the dialer.")
    }

    @SuppressLint("MissingPermission")
    private fun placeCall(contact: PhoneContact, direct: Boolean): ActionResult {
        if (SensitiveNumberGuard.isBlocked(contact.number)) {
            return ActionResult.Blocked("I won't call that number.")
        }
        val granted = context.checkSelfPermission(android.Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        if (direct && granted) {
            start(Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.number}")))
            return ActionResult.Success("Calling ${contact.name}.")
        }
        start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.number}")))
        return ActionResult.Success("Opening the dialer for ${contact.name}. You still press call.")
    }

    private fun draftMessage(action: JarvisAction.SendMessageDraft): ActionResult {
        val channel = action.channel.lowercase()
        val match = if (contacts.hasPermission()) contacts.resolve(action.recipient) else MatchResult.None(action.recipient)
        val contact = when (match) {
            is MatchResult.One -> match.value
            is MatchResult.Many -> return ActionResult.Ambiguous(
                "Which ${action.recipient}? " + match.values.joinToString(", ") { it.name },
            )
            is MatchResult.None -> null
        }
        if (channel == "whatsapp") {
            val number = contact?.number?.filter { it.isDigit() }
            if (!number.isNullOrBlank()) {
                val uri = Uri.parse("https://wa.me/$number?text=${Uri.encode(action.body)}")
                start(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
                return ActionResult.Success("Opening WhatsApp with a draft for ${contact.name}. You still send it.")
            }
            start(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, action.body)
                    setPackage("com.whatsapp")
                },
            )
            return ActionResult.Success("Opening WhatsApp with your draft. Pick the chat and send it yourself.")
        }
        val number = contact?.number?.filter { it.isDigit() || it == '+' }
        if (number.isNullOrBlank()) {
            start(
                Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, action.body)
                },
            )
            return ActionResult.Success("I couldn't find a number for ${action.recipient}, so I opened a share sheet with the draft.")
        }
        val uri = Uri.parse("smsto:$number")
        start(
            Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", action.body)
            },
        )
        return ActionResult.Success("Draft ready for ${contact.name}. Nothing is sent until you hit send.")
    }

    private fun setAlarm(action: JarvisAction.SetAlarm): ActionResult {
        start(
            Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, action.hour)
                putExtra(AlarmClock.EXTRA_MINUTES, action.minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, action.label.ifBlank { "Alarm" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            },
        )
        val label = "%d:%02d".format(action.hour, action.minute)
        return ActionResult.Success("Opening the clock for $label. Confirm it there.")
    }

    private fun setTimer(action: JarvisAction.SetTimer): ActionResult {
        start(
            Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, action.seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, action.label.ifBlank { "Timer" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            },
        )
        return ActionResult.Success("Opening a ${action.seconds}-second timer.")
    }

    private fun calendar(action: JarvisAction.CreateCalendarEvent): ActionResult {
        start(
            Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, action.title)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, action.startEpochMs)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, action.endEpochMs)
            },
        )
        return ActionResult.Success("Calendar draft ready for ${action.title}. Save it if it looks right.")
    }

    private fun reminder(action: JarvisAction.CreateReminder): ActionResult {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val code = (action.triggerEpochMs xor action.message.hashCode().toLong()).toInt()
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_MESSAGE, action.message)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            code,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val trigger = action.triggerEpochMs.coerceAtLeast(System.currentTimeMillis() + 5_000L)
        val canExact = Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()
        if (canExact) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
        }
        return ActionResult.Success("Reminder set. I'll notify you on this phone.")
    }

    private var torchOn = false
    private var torchId: String? = null

    private fun flashlight(enabled: Boolean?): ActionResult {
        if (context.checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("I need camera permission to use the flashlight.")
        }
        val cameras = context.getSystemService(CameraManager::class.java)
        val id = torchId ?: cameras.cameraIdList.firstOrNull { cameraId ->
            cameras.getCameraCharacteristics(cameraId)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) return ActionResult.Failure("This phone doesn't have a flashlight I can use.")
        torchId = id
        val turnOn = enabled ?: !torchOn
        cameras.setTorchMode(id, turnOn)
        torchOn = turnOn
        return ActionResult.Success(if (turnOn) "Flashlight on." else "Flashlight off.")
    }

    private fun maps(query: String?): ActionResult {
        val uri = if (query.isNullOrBlank()) Uri.parse("geo:0,0") else Uri.parse("geo:0,0?q=${Uri.encode(query)}")
        start(Intent(Intent.ACTION_VIEW, uri))
        return ActionResult.Success(if (query.isNullOrBlank()) "Opening maps." else "Looking up $query in maps.")
    }

    private fun navigate(place: String): ActionResult {
        val uri = Uri.parse("google.navigation:q=${Uri.encode(place)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps")
        if (intent.resolveActivity(context.packageManager) == null) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(place)}")))
        } else {
            start(intent)
        }
        return ActionResult.Success("Starting navigation to $place.")
    }

    private fun play(target: String?): ActionResult {
        if (!target.isNullOrBlank()) {
            when (val opened = openApp(target)) {
                is ActionResult.Success -> {
                    mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                    return ActionResult.Success("Opening $target and sending play.")
                }
                else -> return opened
            }
        }
        mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        return ActionResult.Success("Sending play. If nothing starts, tell me which app.")
    }

    private fun mediaKey(keyCode: Int) {
        val audio = context.getSystemService(AudioManager::class.java)
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    private fun volume(action: JarvisAction.ChangeVolume): ActionResult {
        val audio = context.getSystemService(AudioManager::class.java)
        val stream = AudioManager.STREAM_MUSIC
        val level = action.level
        if (level != null) {
            val max = audio.getStreamMaxVolume(stream)
            val target = (level.coerceIn(0, 100) / 100f * max).toInt()
            audio.setStreamVolume(stream, target, AudioManager.FLAG_SHOW_UI)
            return ActionResult.Success("Media volume set.")
        }
        val dir = when (action.direction) {
            "down", "lower", "quieter" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> AudioManager.ADJUST_RAISE
        }
        audio.adjustStreamVolume(stream, dir, AudioManager.FLAG_SHOW_UI)
        return ActionResult.Success("Volume adjusted.")
    }

    private fun settingsPanel(panel: String): ActionResult {
        if (panel.lowercase() in ActionSafetyManager.BLOCKED_PANELS) {
            return ActionResult.Blocked("I can't change security settings.")
        }
        val actionName = when (panel.lowercase()) {
            "wifi", "network" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(actionName)
        if (actionName == Settings.ACTION_APP_NOTIFICATION_SETTINGS) {
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
        start(intent)
        return ActionResult.Success("Opening settings.")
    }

    private suspend fun notifications(): ActionResult {
        val prefs = settings.snapshot()
        if (!prefs.notificationSummaryEnabled) {
            return ActionResult.Failure("Notification summaries are off. You can allow them in Settings, then enable notification access for JARVIS.")
        }
        val notes = NotificationInbox.snapshot(prefs.excludedPackages)
        if (notes.isEmpty()) return ActionResult.Success("I don't see any new notifications I was allowed to read.")
        val summary = notes.take(5).joinToString(". ") { note ->
            val title = note.title.ifBlank { note.packageName.substringAfterLast('.') }
            val body = note.text.take(80)
            if (body.isBlank()) title else "$title: $body"
        }
        return ActionResult.Success("Recent notifications. $summary")
    }

    private fun battery(): ActionResult {
        val bm = context.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return ActionResult.Success("Battery is at $pct percent.")
    }

    private fun time(): ActionResult {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR)
        val displayHour = if (hour == 0) 12 else hour
        val minute = cal.get(Calendar.MINUTE)
        val ampm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
        return ActionResult.Success("It's $displayHour:${minute.toString().padStart(2, '0')} $ampm.")
    }

    private fun device(): ActionResult {
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        return ActionResult.Success("$maker ${Build.MODEL}, Android ${Build.VERSION.RELEASE}.")
    }

    private fun schedule(): ActionResult {
        if (context.checkSelfPermission(android.Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return ActionResult.Failure("I don't have calendar access yet. You can allow it in Settings.")
        }
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val cursor = context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            arrayOf(CalendarContract.Events.TITLE, CalendarContract.Events.DTSTART),
            "${CalendarContract.Events.DTSTART} >= ? AND ${CalendarContract.Events.DTSTART} < ?",
            arrayOf(start.timeInMillis.toString(), end.timeInMillis.toString()),
            "${CalendarContract.Events.DTSTART} ASC",
        ) ?: return ActionResult.Failure("I couldn't read the calendar.")
        val lines = mutableListOf<String>()
        cursor.use {
            val titleIdx = it.getColumnIndex(CalendarContract.Events.TITLE)
            val startIdx = it.getColumnIndex(CalendarContract.Events.DTSTART)
            while (it.moveToNext() && lines.size < 8) {
                val title = if (titleIdx >= 0) it.getString(titleIdx).orEmpty() else "Event"
                val whenMs = if (startIdx >= 0) it.getLong(startIdx) else 0L
                val cal = Calendar.getInstance().apply { timeInMillis = whenMs }
                val hour = cal.get(Calendar.HOUR).let { h -> if (h == 0) 12 else h }
                val minute = cal.get(Calendar.MINUTE).toString().padStart(2, '0')
                val ampm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
                lines += "$hour:$minute $ampm $title"
            }
        }
        return if (lines.isEmpty()) ActionResult.Success("Your calendar is clear for the rest of today.")
        else ActionResult.Success("Today: ${lines.joinToString(". ")}.")
    }

    private suspend fun screen(): ActionResult {
        val prefs = settings.snapshot()
        if (!prefs.screenContextEnabled || !ScreenContextStore.enabled) {
            return ActionResult.Failure("Screen context is off. Turn it on in Settings and enable the JARVIS accessibility service. I never read the screen in the background.")
        }
        val text = ScreenContextStore.text.trim()
        if (text.isBlank()) {
            return ActionResult.Failure("I can't see screen text yet. Open the screen you care about, then ask again.")
        }
        val clipped = text.take(2500)
        val plan = brain.plan(
            PlanRequest(
                history = emptyList(),
                userText = "Describe what is on the user's screen from this visible text. Skip passwords, codes, and card numbers if any slipped through. Be concise.\n\n$clipped",
                personality = Personality.MINIMAL,
                assistantName = prefs.assistantName,
                memoryLines = emptyList(),
                useTools = false,
            ),
        )
        val spoken = plan.text?.takeIf { it.isNotBlank() }
            ?: "Here's what I can see: ${clipped.take(280)}"
        return if (plan.failure != null && plan.text.isNullOrBlank()) {
            ActionResult.Success("Here's the visible text: ${clipped.take(320)}")
        } else {
            ActionResult.Success(spoken)
        }
    }

    private suspend fun forget(action: JarvisAction.ForgetMemory): ActionResult {
        if (action.deleteAll) {
            memory.forgetAll()
            return ActionResult.Success("All memories are deleted.")
        }
        val count = memory.forgetMatch(action.query)
        return if (count == 0) ActionResult.Failure("I couldn't find a memory matching that.")
        else ActionResult.Success("Forgot $count ${if (count == 1) "memory" else "memories"}.")
    }

    private fun start(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
