package com.jarvis.assistant.logging

import android.util.Log
import java.util.ArrayDeque

object DevLog {
    private val lines = ArrayDeque<String>()

    fun add(tag: String, message: String) {
        val safe = LogRedactor.redact(message).take(240)
        val line = "${System.currentTimeMillis()} $tag $safe"
        synchronized(lines) {
            lines.addLast(line)
            while (lines.size > 250) lines.removeFirst()
        }
    }

    fun dump(): String = synchronized(lines) { lines.joinToString("\n") }
}

class AndroidJarvisLogger : JarvisLogger {
    override fun d(tag: String, message: String) {
        val safe = LogRedactor.redact(message)
        Log.d(tag, safe)
        DevLog.add(tag, safe)
    }

    override fun e(tag: String, message: String, throwable: Throwable?) {
        val safe = LogRedactor.redact(message)
        Log.e(tag, safe, throwable)
        DevLog.add(tag, safe + (throwable?.let { " ${it.javaClass.simpleName}" } ?: ""))
    }
}
