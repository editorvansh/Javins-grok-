package com.jarvis.assistant.actions

import java.util.ArrayDeque

data class InboxNote(
    val packageName: String,
    val title: String,
    val text: String,
    val postedAt: Long,
)

/**
 * In-memory only. Cleared when the process dies. Never written to disk.
 */
object NotificationInbox {
    private val items = ArrayDeque<InboxNote>()

    @Synchronized
    fun add(note: InboxNote, enabled: Boolean, excluded: Set<String>) {
        if (!enabled) return
        if (note.packageName in excluded) return
        if (note.title.isBlank() && note.text.isBlank()) return
        items.addFirst(note)
        while (items.size > 40) items.removeLast()
    }

    @Synchronized
    fun snapshot(excluded: Set<String>): List<InboxNote> =
        items.filter { it.packageName !in excluded }.take(15)

    @Synchronized
    fun clear() = items.clear()
}

/**
 * Latest visible screen text. Updated only while the user has screen context enabled.
 * Password fields are never stored. Not persisted.
 */
object ScreenContextStore {
    @Volatile
    var enabled: Boolean = false

    @Volatile
    var packageName: String = ""

    @Volatile
    var text: String = ""

    fun clear() {
        packageName = ""
        text = ""
    }
}
