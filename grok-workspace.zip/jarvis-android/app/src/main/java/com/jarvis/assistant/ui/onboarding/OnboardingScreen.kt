package com.jarvis.assistant.ui.onboarding

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.data.prefs.AssistantSettings
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.ui.theme.Mist
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(container: AppContainer, settings: AssistantSettings) {
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val notifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val contacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val calendar = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Setup ${pager.currentPage + 1} / ${pages.size}", color = Mist)
        Spacer(Modifier.height(12.dp))
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val item = pages[page]
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(item.title, style = MaterialTheme.typography.headlineMedium)
                Text(item.body, color = Mist, style = MaterialTheme.typography.bodyLarge)
            }
        }
        itemAction(pager.currentPage, settings.assistantName) {
            when (pager.currentPage) {
                3 -> mic.launch(Manifest.permission.RECORD_AUDIO)
                4 -> notifications.launch(Manifest.permission.POST_NOTIFICATIONS)
                5 -> contacts.launch(Manifest.permission.READ_CONTACTS)
                6 -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:${context.packageName}"),
                    )
                    context.startActivity(intent)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (pager.currentPage < pages.lastIndex) {
                    scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                } else {
                    scope.launch { container.settings.update { it.copy(onboardingDone = true) } }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (pager.currentPage == pages.lastIndex) "Enter JARVIS" else "Continue") }
        if (pager.currentPage in 3..7) {
            OutlinedButton(
                onClick = { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Skip for now") }
        }
    }
}

@Composable
private fun itemAction(page: Int, name: String, onClick: () -> Unit) {
    val label = when (page) {
        3 -> "Allow microphone"
        4 -> "Allow notifications"
        5 -> "Allow contacts"
        6 -> "Allow overlay"
        else -> return
    }
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(label) }
    if (page == 7) {
        Text("Wake word uses a visible foreground notification. $name will not listen in secret.", color = Mist)
    }
}

private data class Page(val title: String, val body: String)

private val pages = listOf(
    Page("Welcome to JARVIS", "A voice-first assistant that stays nearby without taking over the screen. Original design. No borrowed movie assets."),
    Page("Gemini", "JARVIS reasons with Gemini. Put your key in Settings, or point it at the included proxy so the key never sits in the app. Basic commands still work offline."),
    Page("Voice", "ElevenLabs speaks if you add a key and voice id. Otherwise the phone's own voice is used. You can test it in Settings."),
    Page("Microphone", "Voice needs the microphone. Android shows the usual indicator while listening. Typing always works if you say no."),
    Page("Notifications", "Needed for the listening status and for reminders you create. Optional."),
    Page("Contacts", "Used only when you ask to call or draft a message. JARVIS asks before either one, and never dials emergency numbers."),
    Page("Overlay", "A small orb can sit at the edge of the screen. Android asks for display-over-apps permission. You can turn it off any time."),
    Page("Wake word", "Optional. While enabled, a persistent notification stays up and the mic indicator is visible. Say the assistant name, then your request. Turn it off whenever you want."),
    Page("Privacy", "Keys stay in encrypted app storage. Memories are visible and deletable. Screen text and notification summaries are off until you opt in. Password fields are skipped. Nothing records audio to a file."),
    Page("Ready", "You can change every choice later. Sensitive actions always ask. Blocked actions never run, no matter what the model says."),
)
