package com.jarvis.assistant.security

import com.jarvis.assistant.domain.model.JarvisAction
import com.jarvis.assistant.domain.model.RiskLevel
import com.jarvis.assistant.domain.model.SafetyDecision

/**
 * The only risk authority. Model text cannot change a decision.
 * Blocked actions are never executed, even if a caller passes confirmedByUser.
 */
class ActionSafetyManager(
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    fun classify(action: JarvisAction): SafetyDecision {
        val suspicious = suspiciousText(action)
        if (suspicious != null) {
            return block("I won't run that. It looks like a system command, not a phone action.")
        }
        return when (action) {
            is JarvisAction.Rejected -> block(action.detail.ifBlank { "That action isn't allowed." })
            is JarvisAction.OpenApp -> allow("Open ${action.appName}.")
            is JarvisAction.SearchWeb -> allow("Search the web.")
            is JarvisAction.OpenUrl -> classifyUrl(action.url)
            is JarvisAction.CallContact -> confirm(
                "Calls need a quick confirmation.",
                "Call ${action.name}? I'll open the dialer only after you say yes.",
            )
            is JarvisAction.ShowDialer -> allow("Open the dialer.")
            is JarvisAction.SendMessageDraft -> confirm(
                "Messages need confirmation before a draft is opened.",
                "Draft \"${action.body.take(140)}\" to ${action.recipient}?",
            )
            is JarvisAction.SetAlarm -> allow("Set an alarm. The clock app will show it.")
            is JarvisAction.SetTimer -> allow("Set a timer.")
            is JarvisAction.CreateCalendarEvent -> allow("Open a calendar draft for you to save.")
            is JarvisAction.CreateReminder -> allow("Create a reminder on this phone.")
            JarvisAction.OpenCamera -> allow("Open the camera.")
            is JarvisAction.ToggleFlashlight -> allow("Toggle the flashlight.")
            is JarvisAction.OpenMaps -> allow("Open maps.")
            is JarvisAction.NavigateTo -> allow("Open navigation.")
            is JarvisAction.PlayMedia -> allow("Play media.")
            JarvisAction.PauseMedia -> allow("Pause media.")
            is JarvisAction.ChangeVolume -> classifyVolume(action)
            is JarvisAction.LaunchSettings -> classifySettings(action.panel)
            JarvisAction.ReadNotifications -> allow("Read notifications already shared with JARVIS.")
            JarvisAction.GetBatteryStatus -> allow("Check battery.")
            JarvisAction.GetCurrentTime -> allow("Check the time.")
            JarvisAction.GetDeviceInformation -> allow("Read basic device info.")
            JarvisAction.GetSchedule -> allow("Read today's calendar events if access was granted.")
            JarvisAction.ReadScreen -> confirm(
                "Screen reading needs confirmation for this request.",
                "Look at what's on your screen and describe it? I only read when you agree, and I skip password fields.",
            )
            is JarvisAction.RememberFact -> allow("Save a memory you can edit later.")
            is JarvisAction.ForgetMemory -> confirm(
                "Deleting memory needs confirmation.",
                if (action.deleteAll) {
                    "Delete all of my memories?"
                } else {
                    "Forget memories matching \"${action.query}\"?"
                },
            )
        }
    }

    private fun classifyUrl(url: String): SafetyDecision {
        val trimmed = url.trim()
        val scheme = trimmed.substringBefore(':', "").lowercase()
        if (scheme != "http" && scheme != "https") {
            return block("I only open normal http and https links.")
        }
        if (trimmed.contains("javascript:", ignoreCase = true)) {
            return block("I won't open that link.")
        }
        return allow("Open the link.")
    }

    private fun classifyVolume(action: JarvisAction.ChangeVolume): SafetyDecision {
        val level = action.level
        if (level != null && (level <= 0 || level >= 100)) {
            return confirm(
                "Extreme volume changes need confirmation.",
                if (level <= 0) "Mute the media volume?" else "Set the media volume to maximum?",
            )
        }
        return allow("Change the volume.")
    }

    private fun classifySettings(panel: String): SafetyDecision {
        val key = panel.trim().lowercase()
        if (key in BLOCKED_PANELS) {
            return block("I can't change security or device-admin settings.")
        }
        if (key !in ALLOWED_PANELS && key.isNotBlank() && key != "general" && key != "settings") {
            // Unknown panels fall back to the main Settings screen rather than an arbitrary intent.
            return allow("Open Settings.")
        }
        return allow("Open Settings.")
    }

    private fun suspiciousText(action: JarvisAction): String? {
        val blob = actionBlob(action)
        if (SHELL.containsMatchIn(blob)) return blob
        if (blob.contains("BEGIN PRIVATE KEY", ignoreCase = true)) return blob
        return null
    }

    private fun actionBlob(action: JarvisAction): String = when (action) {
        is JarvisAction.OpenApp -> action.appName
        is JarvisAction.SearchWeb -> action.query
        is JarvisAction.OpenUrl -> action.url
        is JarvisAction.CallContact -> action.name
        is JarvisAction.ShowDialer -> action.nameOrNumber
        is JarvisAction.SendMessageDraft -> "${action.recipient} ${action.body} ${action.channel}"
        is JarvisAction.SetAlarm -> action.label
        is JarvisAction.SetTimer -> action.label
        is JarvisAction.CreateCalendarEvent -> action.title
        is JarvisAction.CreateReminder -> action.message
        is JarvisAction.ToggleFlashlight -> action.enabled.toString()
        is JarvisAction.OpenMaps -> action.query.orEmpty()
        is JarvisAction.NavigateTo -> action.place
        is JarvisAction.PlayMedia -> action.target.orEmpty()
        is JarvisAction.ChangeVolume -> "${action.direction} ${action.level}"
        is JarvisAction.LaunchSettings -> action.panel
        is JarvisAction.RememberFact -> action.fact
        is JarvisAction.ForgetMemory -> action.query
        is JarvisAction.Rejected -> "${action.toolName} ${action.detail}"
        else -> ""
    }

    private fun allow(reason: String) = SafetyDecision(RiskLevel.LOW_RISK, reason, prompt = "")

    private fun confirm(reason: String, prompt: String) =
        SafetyDecision(RiskLevel.CONFIRMATION_REQUIRED, reason, prompt)

    private fun block(reason: String) = SafetyDecision(RiskLevel.BLOCKED, reason, prompt = "")

    @Suppress("unused")
    private fun clock(): Long = now()

    companion object {
        val ALLOWED_PANELS = setOf(
            "general", "settings", "wifi", "bluetooth", "display", "sound",
            "apps", "battery", "location", "accessibility", "notifications", "network",
        )
        val BLOCKED_PANELS = setOf(
            "security", "lockscreen", "lock_screen", "device_admin", "admin",
            "factory_reset", "reset", "credential", "biometrics", "password",
        )
        private val SHELL = Regex(
            "(?i)(\\brm\\s+-|\\bsudo\\b|runtime\\.exec|getruntime\\(\\)|/system/bin|\\bpm\\s+install\\b|\\badb\\s+|\\bsu\\b)",
        )
    }
}
