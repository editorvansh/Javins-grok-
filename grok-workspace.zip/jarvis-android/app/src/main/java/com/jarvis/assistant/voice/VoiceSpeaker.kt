package com.jarvis.assistant.voice

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.data.prefs.SecretStore
import com.jarvis.assistant.data.prefs.SettingsRepository
import com.jarvis.assistant.logging.JarvisLogger
import com.jarvis.assistant.logging.JarvisTags
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

class VoiceSpeaker(
    private val context: Context,
    private val secrets: SecretStore,
    private val settings: SettingsRepository,
    private val logger: JarvisLogger,
) {
    private val client = OkHttpClient.Builder()
        .callTimeout(35, TimeUnit.SECONDS)
        .build()
    private var player: MediaPlayer? = null
    private var androidTts: TextToSpeech? = null
    private var ttsReady = false

    suspend fun speak(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val prefs = settings.snapshot()
        val key = secrets.elevenLabsKey()
        val usedCloud = if (key.isNotBlank() && prefs.voiceId.isNotBlank()) {
            runCatching { speakEleven(clean, key, prefs.voiceId, prefs.speechRate) }.getOrDefault(false)
        } else {
            false
        }
        if (!usedCloud) {
            logger.d(JarvisTags.VOICE, "Using Android TTS fallback, chars=${clean.length}")
            speakAndroid(clean, prefs.speechRate, prefs.languageTag)
        }
    }

    fun stop() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        androidTts?.stop()
    }

    private suspend fun speakEleven(text: String, apiKey: String, voiceId: String, rate: Float): Boolean {
        val speed = rate.coerceIn(0.7f, 1.2f)
        val payload = JSONObject()
            .put("text", text.take(2500))
            .put("model_id", "eleven_multilingual_v2")
            .put(
                "voice_settings",
                JSONObject()
                    .put("stability", 0.45)
                    .put("similarity_boost", 0.75)
                    .put("speed", speed.toDouble()),
            )
        val request = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/${voiceId.trim()}?output_format=mp3_44100_128")
            .addHeader("xi-api-key", apiKey)
            .addHeader("Accept", "audio/mpeg")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        logger.d(JarvisTags.VOICE, "ElevenLabs request chars=${text.length}")
        val file = withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    logger.e(JarvisTags.VOICE, "ElevenLabs HTTP ${response.code}")
                    return@withContext null
                }
                val bytes = response.body?.bytes() ?: return@withContext null
                val out = File(context.cacheDir, "jarvis-tts.mp3")
                out.writeBytes(bytes)
                out
            }
        } ?: return false
        return playFile(file)
    }

    private suspend fun playFile(file: File): Boolean = suspendCancellableCoroutine { cont ->
        stop()
        val media = MediaPlayer()
        player = media
        media.setOnCompletionListener {
            it.release()
            if (player === it) player = null
            file.delete()
            if (cont.isActive) cont.resume(true)
        }
        media.setOnErrorListener { mp, _, _ ->
            mp.release()
            if (player === mp) player = null
            file.delete()
            if (cont.isActive) cont.resume(false)
            true
        }
        try {
            media.setDataSource(file.absolutePath)
            media.prepare()
            media.start()
        } catch (e: Exception) {
            logger.e(JarvisTags.VOICE, "Playback failed", e)
            if (cont.isActive) cont.resume(false)
        }
        cont.invokeOnCancellation { stop() }
    }

    private suspend fun speakAndroid(text: String, rate: Float, languageTag: String) {
        val engine = ensureAndroidTts() ?: return
        engine.setSpeechRate(rate.coerceIn(0.5f, 1.6f))
        val locale = Locale.forLanguageTag(languageTag.ifBlank { "en-US" })
        engine.language = locale
        suspendCancellableCoroutine { cont ->
            val id = "jarvis-${System.currentTimeMillis()}"
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (cont.isActive) cont.resume(Unit)
                }
            })
            val params = android.os.Bundle()
            engine.speak(text.take(3000), TextToSpeech.QUEUE_FLUSH, params, id)
            cont.invokeOnCancellation { engine.stop() }
        }
    }

    private suspend fun ensureAndroidTts(): TextToSpeech? {
        androidTts?.let { if (ttsReady) return it }
        return suspendCancellableCoroutine { cont ->
            var resumed = false
            val tts = TextToSpeech(context) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (!resumed) {
                    resumed = true
                    cont.resume(if (ttsReady) androidTts else null)
                }
            }
            androidTts = tts
        }
    }
}
