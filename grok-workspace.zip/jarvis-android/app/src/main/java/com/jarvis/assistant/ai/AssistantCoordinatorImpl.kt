package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.ActionResult
import com.jarvis.assistant.domain.model.AssistantConfigSource
import com.jarvis.assistant.domain.model.AssistantCoordinator
import com.jarvis.assistant.domain.model.AssistantPhase
import com.jarvis.assistant.domain.model.BrainResult
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.CoordinatorResult
import com.jarvis.assistant.domain.model.GeminiBrain
import com.jarvis.assistant.domain.model.ActionGateway
import com.jarvis.assistant.domain.model.JarvisAction
import com.jarvis.assistant.domain.model.MemorySource
import com.jarvis.assistant.domain.model.PlanRequest
import com.jarvis.assistant.domain.model.RiskLevel
import com.jarvis.assistant.security.ActionSafetyManager

class AssistantCoordinatorImpl(
    private val brain: GeminiBrain,
    private val local: LocalCommandParser,
    private val safety: ActionSafetyManager,
    private val gateway: ActionGateway,
    private val memory: MemorySource,
    private val config: AssistantConfigSource,
    private val conversation: ConversationManager,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : AssistantCoordinator {

    override fun messages(): List<ChatMessage> = conversation.history()

    override fun endSession() {
        conversation.end()
    }

    override fun isSessionActive(): Boolean {
        conversation.purgeIfExpired(clock())
        return conversation.isActive()
    }

    override suspend fun handleText(raw: String): CoordinatorResult {
        val text = raw.trim()
        val cfg = config.current()
        conversation.timeoutMs = cfg.timeoutMs
        conversation.purgeIfExpired(clock())
        if (text.isEmpty()) return snapshot("I didn't catch that.", AssistantPhase.ERROR, "I didn't catch that.")

        val normalized = Utterance.stripWake(text, cfg.assistantName).ifBlank { text }

        val pending = conversation.pending
        if (pending != null) {
            if (Utterance.isAffirmative(normalized)) {
                addUser(text)
                return finishConfirmed(pending)
            }
            if (Utterance.isNegative(normalized)) {
                addUser(text)
                conversation.setPending(null)
                return speak("Okay. I won't do that.", AssistantPhase.IDLE, pendingPrompt = null)
            }
            conversation.setPending(null)
        }

        if (Utterance.isWakeOnly(text, cfg.assistantName)) {
            addUser(text)
            return speak("Yes?", AssistantPhase.IDLE, pendingPrompt = null)
        }

        addUser(text)

        val plan = try {
            brain.plan(
                PlanRequest(
                    history = conversation.history().dropLast(1).takeLast(12),
                    userText = normalized,
                    personality = cfg.personality,
                    assistantName = cfg.assistantName,
                    memoryLines = if (cfg.memoryEnabled) memory.lines().take(20) else emptyList(),
                ),
            )
        } catch (e: Exception) {
            BrainResult(text = null, actions = emptyList(), failure = humanBrainError(e.message))
        }

        var actions = plan.actions.filterNot { it is JarvisAction.Rejected }.take(4)
        val rejected = plan.actions.filterIsInstance<JarvisAction.Rejected>()

        if (actions.isEmpty()) {
            local.parse(normalized)?.let { actions = listOf(it) }
        }

        if (actions.isEmpty() && rejected.isNotEmpty() && plan.text.isNullOrBlank()) {
            return speak(rejected.first().detail, AssistantPhase.ERROR, error = rejected.first().detail)
        }

        if (actions.isEmpty() && plan.failure != null) {
            val offline = offlineReply(normalized)
            return speak(offline ?: plan.failure, if (offline == null) AssistantPhase.ERROR else AssistantPhase.IDLE, error = if (offline == null) plan.failure else null)
        }

        if (actions.isEmpty()) {
            val spoken = plan.text?.takeIf { it.isNotBlank() } ?: "I'm here. What would you like to do?"
            return speak(spoken, AssistantPhase.IDLE, pendingPrompt = null)
        }

        val pieces = mutableListOf<String>()
        plan.text?.takeIf { it.isNotBlank() && actions.isNotEmpty() }?.let { /* spoken after tools */ }
        var phase = AssistantPhase.IDLE
        var error: String? = null
        var pendingPrompt: String? = null

        for (action in actions) {
            val decision = safety.classify(action)
            when (decision.level) {
                RiskLevel.BLOCKED -> {
                    pieces += decision.reason
                    phase = AssistantPhase.ERROR
                    error = decision.reason
                    break
                }
                RiskLevel.CONFIRMATION_REQUIRED -> {
                    conversation.setPending(action)
                    pieces += decision.prompt
                    pendingPrompt = decision.prompt
                    break
                }
                RiskLevel.LOW_RISK -> {
                    when (val result = gateway.run(action, confirmedByUser = false)) {
                        is ActionResult.NeedsConfirmation -> {
                            conversation.setPending(action)
                            pieces += result.prompt
                            pendingPrompt = result.prompt
                            break
                        }
                        is ActionResult.Blocked -> {
                            pieces += result.reason
                            phase = AssistantPhase.ERROR
                            error = result.reason
                            break
                        }
                        is ActionResult.Failure -> {
                            pieces += result.message
                            phase = AssistantPhase.ERROR
                            error = result.message
                            break
                        }
                        is ActionResult.Ambiguous -> {
                            pieces += result.message
                            break
                        }
                        is ActionResult.Success -> pieces += result.message
                    }
                }
            }
        }

        val spoken = pieces.joinToString(" ").trim().ifBlank { "Done." }
        return speak(spoken, phase, pendingPrompt, error)
    }

    private suspend fun finishConfirmed(action: JarvisAction): CoordinatorResult {
        val decision = safety.classify(action)
        if (decision.level == RiskLevel.BLOCKED) {
            conversation.setPending(null)
            return speak(decision.reason, AssistantPhase.ERROR, error = decision.reason)
        }
        val result = gateway.run(action, confirmedByUser = true)
        conversation.setPending(null)
        val phase = when (result) {
            is ActionResult.Blocked, is ActionResult.Failure -> AssistantPhase.ERROR
            else -> AssistantPhase.IDLE
        }
        val error = when (result) {
            is ActionResult.Blocked -> result.reason
            is ActionResult.Failure -> result.message
            else -> null
        }
        return speak(result.speech, phase, pendingPrompt = null, error = error)
    }

    private fun addUser(text: String) {
        conversation.add(ChatMessage(ChatMessage.Role.USER, text, clock()))
    }

    private fun speak(
        text: String,
        phase: AssistantPhase,
        pendingPrompt: String? = conversation.pending?.let { safety.classify(it).prompt },
        error: String? = null,
    ): CoordinatorResult {
        conversation.add(ChatMessage(ChatMessage.Role.ASSISTANT, text, clock()))
        return snapshot(text, phase, error, pendingPrompt)
    }

    private fun snapshot(
        spoken: String,
        phase: AssistantPhase,
        error: String? = null,
        pendingPrompt: String? = null,
    ) = CoordinatorResult(
        spokenText = spoken,
        phase = phase,
        messages = conversation.history(),
        pendingPrompt = pendingPrompt,
        error = error,
    )

    private fun humanBrainError(raw: String?): String {
        val msg = raw.orEmpty()
        return when {
            msg.contains("401") || msg.contains("403") || msg.contains("API key", true) ->
                "The Gemini key was rejected. Check it in Settings."
            msg.contains("429") || msg.contains("rate", true) ->
                "Gemini is rate limiting requests. Give it a moment and try again."
            msg.contains("Unable to resolve", true) || msg.contains("timeout", true) || msg.contains("network", true) ->
                "I can't reach Gemini right now. I can still try basic phone commands."
            msg.isBlank() -> "I couldn't reach the AI just now."
            else -> "I couldn't complete that AI request."
        }
    }

    private fun offlineReply(text: String): String? {
        val lower = text.lowercase()
        return when {
            lower in setOf("hi", "hello", "hey", "good morning", "good evening", "thanks", "thank you") ->
                "Hello. I'm here. Add a Gemini key in Settings for full conversation, or ask me to open an app, set an alarm, or check the time."
            else -> null
        }
    }
}
