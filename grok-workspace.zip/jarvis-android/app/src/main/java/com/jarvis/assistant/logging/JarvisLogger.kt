package com.jarvis.assistant.logging

interface JarvisLogger {
    fun d(tag: String, message: String)
    fun e(tag: String, message: String, throwable: Throwable? = null)
}

object NoopLogger : JarvisLogger {
    override fun d(tag: String, message: String) = Unit
    override fun e(tag: String, message: String, throwable: Throwable?) = Unit
}

object LogRedactor {
    private val googleKey = Regex("AIza[0-9A-Za-z_\\-]{10,}")
    private val header =
        Regex("(?i)(api[_-]?key|xi-api-key|authorization|x-goog-api-key)\\s*[:=]\\s*\\S+")
    private val bearer = Regex("(?i)bearer\\s+[A-Za-z0-9\\-._~+/]+=*")

    fun redact(message: String): String =
        message
            .replace(googleKey, "[REDACTED_KEY]")
            .replace(header, "$1=[REDACTED]")
            .replace(bearer, "Bearer [REDACTED]")

    fun safeTag(component: String): String = component.take(23)
}

object JarvisTags {
    const val AI = "JARVIS_AI"
    const val VOICE = "JARVIS_VOICE"
    const val ACTION = "JARVIS_ACTION"
    const val SERVICE = "JARVIS_SERVICE"
    const val PERMISSION = "JARVIS_PERMISSION"
}
