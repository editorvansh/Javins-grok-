package com.jarvis.assistant.di

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.jarvis.assistant.actions.ActionExecutor
import com.jarvis.assistant.actions.AppController
import com.jarvis.assistant.actions.ContactController
import com.jarvis.assistant.actions.ScreenContextStore
import com.jarvis.assistant.ai.AssistantCoordinatorImpl
import com.jarvis.assistant.ai.ConversationManager
import com.jarvis.assistant.ai.GeminiCredentials
import com.jarvis.assistant.ai.GeminiRepository
import com.jarvis.assistant.ai.LocalCommandParser
import com.jarvis.assistant.app.AssistantEngineImpl
import com.jarvis.assistant.automation.AutomationManager
import com.jarvis.assistant.data.db.HistoryRepository
import com.jarvis.assistant.data.db.JarvisDatabase
import com.jarvis.assistant.data.db.MemoryRepository
import com.jarvis.assistant.data.net.OkHttpTransport
import com.jarvis.assistant.data.prefs.AssistantSettings
import com.jarvis.assistant.data.prefs.SecretStore
import com.jarvis.assistant.data.prefs.SettingsRepository
import com.jarvis.assistant.logging.AndroidJarvisLogger
import com.jarvis.assistant.security.ActionSafetyManager
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.voice.VoiceRecognitionManager
import com.jarvis.assistant.voice.VoiceSpeaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class AppContainer(
    application: Application,
    private val scope: CoroutineScope,
) {
    val logger = AndroidJarvisLogger()
    val settings = SettingsRepository(application)
    val secrets = SecretStore(application)

    @Volatile
    var settingsCached: AssistantSettings = AssistantSettings()

    private val database = Room.databaseBuilder(
        application,
        JarvisDatabase::class.java,
        "jarvis.db",
    ).fallbackToDestructiveMigration().build()

    val memory = MemoryRepository(database.memoryDao())
    val history = HistoryRepository(database.messageDao())
    val automations = AutomationManager(application, database.automationDao())
    private val safety = ActionSafetyManager()
    private val gemini = GeminiRepository(
        http = OkHttpTransport(),
        credentials = {
            val current = settingsCached
            GeminiCredentials(
                apiKey = secrets.geminiKey(),
                proxyUrl = current.proxyUrl,
                model = current.geminiModel,
            )
        },
        logger = logger,
    )
    private val coordinator = AssistantCoordinatorImpl(
        brain = gemini,
        local = LocalCommandParser(),
        safety = safety,
        gateway = ActionExecutor(
            context = application,
            safety = safety,
            apps = AppController(application),
            contacts = ContactController(application),
            memory = memory,
            settings = settings,
            brain = gemini,
            logger = logger,
        ),
        memory = memory,
        config = { settingsCached.toConfig() },
        conversation = ConversationManager(),
    )
    private val speaker = VoiceSpeaker(application, secrets, settings, logger)

    lateinit var engine: AssistantEngineImpl
        private set

    init {
        val recognizer = VoiceRecognitionManager(
            context = application,
            logger = logger,
            onPartial = { engine.onPartial(it) },
            onAmplitude = { engine.onAmplitude(it) },
            onResult = { engine.onHeard(it) },
            onError = { engine.onListenError(it) },
        )
        engine = AssistantEngineImpl(
            context = application,
            scope = scope,
            coordinator = coordinator,
            speaker = speaker,
            recognizer = recognizer,
            settings = settings,
            history = history,
            logger = logger,
        )
        scope.launch {
            settings.flow.collect {
                settingsCached = it
                ScreenContextStore.enabled = it.screenContextEnabled
                if (!it.screenContextEnabled) ScreenContextStore.clear()
            }
        }
    }

    fun viewModelFactory(): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(JarvisViewModel::class.java)) {
                return JarvisViewModel(engine) as T
            }
            throw IllegalArgumentException("Unknown model ${modelClass.name}")
        }
    }
}
