package com.jarvis.assistant.domain.model

enum class AssistantPhase {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    EXECUTING,
    ERROR,
}

enum class Personality(val id: String, val label: String) {
    PROFESSIONAL("professional", "Professional"),
    FRIENDLY("friendly", "Friendly"),
    COMPANION("companion", "Companion"),
    MINIMAL("minimal", "Minimal"),
    ;

    companion object {
        fun fromId(id: String): Personality =
            entries.firstOrNull { it.id == id } ?: FRIENDLY
    }
}

enum class RiskLevel {
    LOW_RISK,
    CONFIRMATION_REQUIRED,
    BLOCKED,
}

data class ChatMessage(
    val role: Role,
    val text: String,
    val timestamp: Long,
) {
    enum class Role { USER, ASSISTANT, SYSTEM }
}

data class SafetyDecision(
    val level: RiskLevel,
    val reason: String,
    val prompt: String,
)

sealed interface ActionResult {
    val speech: String

    data class Success(val message: String) : ActionResult {
        override val speech: String get() = message
    }

    data class Failure(val message: String) : ActionResult {
        override val speech: String get() = message
    }

    data class Blocked(val reason: String) : ActionResult {
        override val speech: String get() = reason
    }

    data class NeedsConfirmation(val prompt: String) : ActionResult {
        override val speech: String get() = prompt
    }

    data class Ambiguous(val message: String) : ActionResult {
        override val speech: String get() = message
    }
}

/**
 * Structured actions the assistant is allowed to ask for.
 * There is intentionally no "confirmed" or "force" field.
 * Only the app, after a real user reply, may pass confirmedByUser = true.
 */
sealed interface JarvisAction {
    data class OpenApp(val appName: String) : JarvisAction
    data class SearchWeb(val query: String) : JarvisAction
    data class OpenUrl(val url: String) : JarvisAction
    data class CallContact(val name: String) : JarvisAction
    data class ShowDialer(val nameOrNumber: String) : JarvisAction
    data class SendMessageDraft(
        val recipient: String,
        val body: String,
        val channel: String,
    ) : JarvisAction
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : JarvisAction
    data class SetTimer(val seconds: Int, val label: String) : JarvisAction
    data class CreateCalendarEvent(
        val title: String,
        val startEpochMs: Long,
        val endEpochMs: Long,
    ) : JarvisAction
    data class CreateReminder(val message: String, val triggerEpochMs: Long) : JarvisAction
    data object OpenCamera : JarvisAction
    data class ToggleFlashlight(val enabled: Boolean?) : JarvisAction
    data class OpenMaps(val query: String?) : JarvisAction
    data class NavigateTo(val place: String) : JarvisAction
    data class PlayMedia(val target: String?) : JarvisAction
    data object PauseMedia : JarvisAction
    data class ChangeVolume(val direction: String, val level: Int?) : JarvisAction
    data class LaunchSettings(val panel: String) : JarvisAction
    data object ReadNotifications : JarvisAction
    data object GetBatteryStatus : JarvisAction
    data object GetCurrentTime : JarvisAction
    data object GetDeviceInformation : JarvisAction
    data object ReadScreen : JarvisAction
    data object GetSchedule : JarvisAction
    data class RememberFact(val fact: String) : JarvisAction
    data class ForgetMemory(val query: String, val deleteAll: Boolean) : JarvisAction
    data class Rejected(val toolName: String, val detail: String) : JarvisAction
}

data class PlanRequest(
    val history: List<ChatMessage>,
    val userText: String,
    val personality: Personality,
    val assistantName: String,
    val memoryLines: List<String>,
    val useTools: Boolean = true,
)

data class BrainResult(
    val text: String?,
    val actions: List<JarvisAction>,
    val failure: String? = null,
)

data class AssistantConfig(
    val assistantName: String = "Jarvis",
    val personality: Personality = Personality.FRIENDLY,
    val timeoutMs: Long = 30_000L,
    val memoryEnabled: Boolean = true,
)

data class CoordinatorResult(
    val spokenText: String,
    val phase: AssistantPhase,
    val messages: List<ChatMessage>,
    val pendingPrompt: String? = null,
    val error: String? = null,
)

fun interface GeminiBrain {
    suspend fun plan(request: PlanRequest): BrainResult
}

fun interface ActionGateway {
    suspend fun run(action: JarvisAction, confirmedByUser: Boolean): ActionResult
}

interface MemorySource {
    suspend fun lines(): List<String>
    suspend fun remember(fact: String)
    suspend fun forgetMatch(query: String): Int
    suspend fun forgetAll()
}

fun interface AssistantConfigSource {
    fun current(): AssistantConfig
}

interface AssistantCoordinator {
    suspend fun handleText(raw: String): CoordinatorResult
    fun messages(): List<ChatMessage>
    fun endSession()
    fun isSessionActive(): Boolean
}
