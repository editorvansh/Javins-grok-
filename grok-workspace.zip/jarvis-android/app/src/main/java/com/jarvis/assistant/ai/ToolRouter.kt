package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.JarvisAction

/**
 * Maps model function calls onto the allow-list.
 * Ignores any argument named confirmed, force, skip, bypass, or shell.
 */
object ToolRouter {
    private val ignoredArgs = setOf(
        "confirmed", "confirm", "userconfirmed", "force", "skip_confirmation",
        "skipconfirmation", "bypass", "bypass_safety", "shell", "command", "cmd",
    )

    fun fromCall(rawName: String, rawArgs: Map<String, Any?>): JarvisAction {
        val name = rawName.trim().lowercase().replace('-', '_')
        val args = rawArgs.filterKeys { it.lowercase() !in ignoredArgs }
        if (name !in ToolCatalog.names) {
            return JarvisAction.Rejected(
                toolName = name.ifBlank { "unknown" },
                detail = "I can't run \"$rawName\". It isn't in the allowed tool list.",
            )
        }
        return try {
            when (name) {
                "open_app" -> {
                    val app = str(args, "app_name", "name", "app", "package", "package_name")
                    if (app.isBlank()) reject(name, "Which app should I open?") else JarvisAction.OpenApp(app.take(80))
                }
                "search_web" -> {
                    val q = str(args, "query", "q", "text")
                    if (q.isBlank()) reject(name, "What should I search for?") else JarvisAction.SearchWeb(q.take(300))
                }
                "open_url" -> {
                    val url = str(args, "url", "link")
                    if (url.isBlank()) reject(name, "Which link?") else JarvisAction.OpenUrl(url.take(500))
                }
                "call_contact" -> {
                    val who = str(args, "name", "contact", "target")
                    if (who.isBlank()) reject(name, "Who should I call?") else JarvisAction.CallContact(who.take(80))
                }
                "show_dialer" -> {
                    val who = str(args, "target", "name", "number")
                    if (who.isBlank()) reject(name, "Who should I show in the dialer?") else JarvisAction.ShowDialer(who.take(80))
                }
                "send_message_draft" -> {
                    val who = str(args, "recipient", "name", "contact", "to")
                    val body = str(args, "body", "message", "text")
                    val channel = str(args, "channel", "app").ifBlank { "sms" }.lowercase()
                    if (who.isBlank() || body.isBlank()) {
                        reject(name, "I need a recipient and a message.")
                    } else {
                        JarvisAction.SendMessageDraft(who.take(80), body.take(500), channel.take(20))
                    }
                }
                "set_alarm" -> {
                    val hour = int(args, "hour")
                    val minute = int(args, "minute") ?: 0
                    if (hour == null || hour !in 0..23 || minute !in 0..59) {
                        reject(name, "I need a valid hour and minute for the alarm.")
                    } else {
                        JarvisAction.SetAlarm(hour, minute, str(args, "label", "message").take(80))
                    }
                }
                "set_timer" -> {
                    val seconds = int(args, "seconds", "duration_seconds") ?: 0
                    if (seconds !in 1..(24 * 60 * 60)) reject(name, "That timer length isn't valid.")
                    else JarvisAction.SetTimer(seconds, str(args, "label", "message").take(80))
                }
                "create_calendar_event" -> {
                    val title = str(args, "title", "name").ifBlank { "Event" }
                    val start = long(args, "start_epoch_ms", "start") ?: (System.currentTimeMillis() + 3_600_000L)
                    val end = long(args, "end_epoch_ms", "end") ?: (start + 3_600_000L)
                    JarvisAction.CreateCalendarEvent(title.take(120), start, end.coerceAtLeast(start))
                }
                "create_reminder" -> {
                    val message = str(args, "message", "text", "title")
                    if (message.isBlank()) reject(name, "What should I remind you about?")
                    else {
                        val whenMs = long(args, "trigger_epoch_ms", "when")
                            ?: (System.currentTimeMillis() + 3_600_000L)
                        JarvisAction.CreateReminder(message.take(240), whenMs)
                    }
                }
                "open_camera" -> JarvisAction.OpenCamera
                "toggle_flashlight" -> {
                    val state = str(args, "state", "mode").lowercase()
                    val enabled = when (state) {
                        "on", "true", "enable", "enabled" -> true
                        "off", "false", "disable", "disabled" -> false
                        else -> null
                    }
                    JarvisAction.ToggleFlashlight(enabled)
                }
                "open_maps" -> JarvisAction.OpenMaps(str(args, "query", "place").ifBlank { null })
                "navigate_to" -> {
                    val place = str(args, "place", "destination", "query")
                    if (place.isBlank()) reject(name, "Where should I navigate?") else JarvisAction.NavigateTo(place.take(160))
                }
                "play_media" -> JarvisAction.PlayMedia(str(args, "target", "app").ifBlank { null })
                "pause_media" -> JarvisAction.PauseMedia
                "change_volume" -> {
                    val direction = str(args, "direction", "change").ifBlank { "up" }.lowercase()
                    val level = int(args, "level", "percent")
                    JarvisAction.ChangeVolume(direction.take(16), level)
                }
                "launch_settings" -> JarvisAction.LaunchSettings(str(args, "panel", "screen").ifBlank { "general" }.lowercase())
                "read_notifications" -> JarvisAction.ReadNotifications
                "get_battery_status" -> JarvisAction.GetBatteryStatus
                "get_current_time" -> JarvisAction.GetCurrentTime
                "get_device_information" -> JarvisAction.GetDeviceInformation
                "get_schedule" -> JarvisAction.GetSchedule
                "read_screen" -> JarvisAction.ReadScreen
                "remember_fact" -> {
                    val fact = str(args, "fact", "text", "memory")
                    if (fact.isBlank()) reject(name, "What should I remember?") else JarvisAction.RememberFact(fact.take(280))
                }
                "forget_memory" -> {
                    val deleteAll = bool(args, "delete_all", "all")
                    val query = str(args, "query", "text", "fact")
                    if (!deleteAll && query.isBlank()) reject(name, "Which memory should I forget?")
                    else JarvisAction.ForgetMemory(query.take(120), deleteAll)
                }
                else -> JarvisAction.Rejected(name, "That action isn't allowed.")
            }
        } catch (e: Exception) {
            JarvisAction.Rejected(name, "I couldn't understand that action.")
        }
    }

    private fun reject(name: String, detail: String) = JarvisAction.Rejected(name, detail)

    private fun str(args: Map<String, Any?>, vararg keys: String): String {
        for (key in keys) {
            val value = args.entries.firstOrNull { it.key.equals(key, ignoreCase = true) }?.value ?: continue
            val text = value.toString().trim()
            if (text.isNotEmpty() && !text.equals("null", ignoreCase = true)) return text
        }
        return ""
    }

    private fun int(args: Map<String, Any?>, vararg keys: String): Int? =
        str(args, *keys).toDoubleOrNull()?.toInt()

    private fun long(args: Map<String, Any?>, vararg keys: String): Long? =
        str(args, *keys).toDoubleOrNull()?.toLong()

    private fun bool(args: Map<String, Any?>, vararg keys: String): Boolean =
        str(args, *keys).equals("true", ignoreCase = true)
}
