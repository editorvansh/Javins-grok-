package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.BuildConfig
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.logging.JarvisTags
import com.jarvis.assistant.services.JarvisForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class JarvisApplication : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this, scope)
        JarvisForegroundService.ensureChannels(this)
        scope.launch(Dispatchers.IO) {
            container.secrets.seedIfBlank(
                gemini = BuildConfig.DEV_GEMINI_API_KEY,
                eleven = BuildConfig.DEV_ELEVENLABS_API_KEY,
            )
            val proxy = BuildConfig.DEV_GEMINI_PROXY_URL
            if (proxy.isNotBlank()) {
                container.settings.update { current ->
                    if (current.proxyUrl.isBlank()) current.copy(proxyUrl = proxy) else current
                }
            }
            container.automations.rescheduleAll()
        }
        scope.launch {
            container.settings.flow.collect { settings ->
                val wantsService = settings.wakeEnabled || settings.overlayEnabled
                if (wantsService && settings.onboardingDone) {
                    JarvisForegroundService.start(this@JarvisApplication, JarvisForegroundService.ACTION_SYNC)
                }
            }
        }
        container.logger.d(JarvisTags.SERVICE, "JARVIS application started")
    }
}
