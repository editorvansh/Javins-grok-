package com.jarvis.assistant.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.ui.theme.InkCard
import com.jarvis.assistant.ui.theme.Mist
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun AutomationsScreen(container: AppContainer) {
    val items by container.automations.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("Morning brief") }
    var hour by remember { mutableIntStateOf(8) }
    var minute by remember { mutableIntStateOf(0) }
    var prompt by remember { mutableStateOf("What's on my schedule today?") }
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Automations", style = MaterialTheme.typography.headlineMedium) }
        item {
            Text(
                "Runs a command at a time you choose. Android may delay exact alarms until you allow them. Nothing runs silently without this list.",
                color = Mist,
            )
        }
        items(items, key = { it.id }) { item ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(InkCard).padding(12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name)
                        Text(
                            "%02d:%02d  ${item.prompt}".format(item.hour, item.minute),
                            color = Mist,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    Switch(
                        checked = item.enabled,
                        onCheckedChange = { enabled ->
                            scope.launch { container.automations.setEnabled(item, enabled) }
                        },
                    )
                }
                TextButton(onClick = { scope.launch { container.automations.delete(item.id) } }) {
                    Text("Delete")
                }
            }
        }
        item {
            Text("New", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(hour.toString(), { hour = it.toIntOrNull()?.coerceIn(0, 23) ?: hour }, label = { Text("Hour (0-23)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(minute.toString(), { minute = it.toIntOrNull()?.coerceIn(0, 59) ?: minute }, label = { Text("Minute") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(prompt, { prompt = it }, label = { Text("What should I do?") }, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = {
                scope.launch {
                    container.automations.save(
                        name = name,
                        hour = hour,
                        minute = minute,
                        daysMask = everydayMask(),
                        prompt = prompt,
                        enabled = true,
                    )
                }
            }) { Text("Save automation") }
        }
    }
}

private fun everydayMask(): Int {
    var mask = 0
    for (day in Calendar.SUNDAY..Calendar.SATURDAY) mask = mask or (1 shl day)
    return mask
}
