package com.jarvis.assistant.services

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import com.jarvis.assistant.domain.model.AssistantPhase
import kotlin.math.min

class OrbOverlayView(context: Context) : View(context) {
    private var phase = AssistantPhase.IDLE
    private var amplitude = 0f
    private var spin = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            spin = it.animatedFraction
            invalidate()
        }
        start()
    }

    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun setPhase(next: AssistantPhase) {
        phase = next
        invalidate()
    }

    fun setAmplitude(value: Float) {
        amplitude = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = (72 * resources.displayMetrics.density).toInt()
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(cx, cy) * 0.72f
        val color = when (phase) {
            AssistantPhase.LISTENING -> Color.parseColor("#7AE7FF")
            AssistantPhase.THINKING -> Color.parseColor("#8AA4FF")
            AssistantPhase.SPEAKING -> Color.parseColor("#B8FFF0")
            AssistantPhase.EXECUTING -> Color.parseColor("#3DDC97")
            AssistantPhase.ERROR -> Color.parseColor("#FF5D73")
            AssistantPhase.IDLE -> Color.parseColor("#3D7EFF")
        }
        val pulse = when (phase) {
            AssistantPhase.SPEAKING, AssistantPhase.LISTENING -> 0.08f + amplitude * 0.18f
            AssistantPhase.THINKING -> 0.06f + (kotlin.math.sin(spin * Math.PI * 2).toFloat() * 0.04f)
            else -> 0.04f
        }
        glow.shader = RadialGradient(
            cx, cy, radius * (1.35f + pulse),
            intArrayOf(color, Color.TRANSPARENT),
            floatArrayOf(0.2f, 1f),
            Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, radius * (1.25f + pulse), glow)
        core.color = color
        core.alpha = 230
        canvas.drawCircle(cx, cy, radius * (0.55f + pulse), core)
        ring.color = Color.WHITE
        ring.alpha = 180
        val sweep = when (phase) {
            AssistantPhase.THINKING, AssistantPhase.EXECUTING -> 70f + spin * 220f
            AssistantPhase.LISTENING -> 40f + amplitude * 80f
            else -> 30f
        }
        canvas.drawArc(
            cx - radius, cy - radius, cx + radius, cy + radius,
            spin * 360f, sweep, false, ring,
        )
    }
}
