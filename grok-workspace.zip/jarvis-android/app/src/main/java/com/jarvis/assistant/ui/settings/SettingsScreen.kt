package com.jarvis.assistant.ui.settings

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.data.prefs.AssistantSettings
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.domain.model.Personality
import com.jarvis.assistant.logging.DevLog
import com.jarvis.assistant.ui.theme.Mist
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer, settings: AssistantSettings) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val memories by container.memory.observe().collectAsState(initial = emptyList())
    var gemini by remember(settings) { mutableStateOf(container.secrets.geminiKey()) }
    var eleven by remember(settings) { mutableStateOf(container.secrets.elevenLabsKey()) }
    var exclude by remember(settings.excludedPackages) { mutableStateOf(settings.excludedPackages.joinToString(", ")) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    fun save(block: (AssistantSettings) -> AssistantSettings) {
        scope.launch { container.settings.update(block) }
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Section("General") }
        item {
            OutlinedTextField(
                settings.assistantName,
                { value -> save { it.copy(assistantName = value.take(24)) } },
                label = { Text("Assistant name") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item { ChoiceRow("Language", listOf("en-US", "en-GB", "hi-IN", "es-ES", "fr-FR", "de-DE"), settings.languageTag) { picked -> save { it.copy(languageTag = picked) } } }
        item {
            ChoiceRow("Personality", Personality.entries.map { it.id }, settings.personality.id) { picked ->
                save { it.copy(personality = Personality.fromId(picked)) }
            }
        }
        item { ChoiceRow("Timeout", listOf("15", "30", "60", "120"), settings.timeoutSec.toString()) { picked -> save { it.copy(timeoutSec = picked.toInt()) } } }
        item { ChoiceRow("Theme", listOf("midnight", "void"), settings.theme) { picked -> save { it.copy(theme = picked) } } }

        item { Section("AI") }
        item {
            Text("Prefer the proxy so the Gemini key stays off the phone. A personal key is stored encrypted and is never written to the log.", color = Mist)
        }
        item { ChoiceRow("Model", listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-flash-latest"), settings.geminiModel) { picked -> save { it.copy(geminiModel = picked) } } }
        item {
            OutlinedTextField(
                settings.geminiModel,
                { value -> save { it.copy(geminiModel = value.trim()) } },
                label = { Text("Custom model id") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            OutlinedTextField(
                settings.proxyUrl,
                { value -> save { it.copy(proxyUrl = value.trim()) } },
                label = { Text("Gemini proxy URL") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            OutlinedTextField(
                gemini,
                { gemini = it },
                label = { Text("Gemini API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = { container.secrets.setGeminiKey(gemini) }) { Text("Save Gemini key") }
        }

        item { Section("Voice") }
        item {
            OutlinedTextField(
                eleven,
                { eleven = it },
                label = { Text("ElevenLabs API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = { container.secrets.setElevenLabsKey(eleven) }) { Text("Save ElevenLabs key") }
        }
        item {
            OutlinedTextField(
                settings.voiceId,
                { value -> save { it.copy(voiceId = value.trim()) } },
                label = { Text("Voice ID") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            ChoiceRow("Speed", listOf("0.8", "1.0", "1.1", "1.2"), settings.speechRate.toString()) { picked ->
                save { it.copy(speechRate = picked.toFloat()) }
            }
        }
        item {
            TextButton(onClick = { scope.launch { container.engine.speakOut("Hello. This is ${settings.assistantName}.") } }) {
                Text("Test voice")
            }
        }

        item { Section("Wake, overlay, boot") }
        item { Toggle("Wake listening", settings.wakeEnabled) { checked -> save { it.copy(wakeEnabled = checked) } } }
        item { Text("Wake mode keeps a notification up and uses the microphone indicator. It is never silent.", color = Mist) }
        item { Toggle("Overlay orb", settings.overlayEnabled) { checked -> save { it.copy(overlayEnabled = checked) } } }
        item { Toggle("Start after reboot", settings.startOnBoot) { checked -> save { it.copy(startOnBoot = checked) } } }
        item {
            TextButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${context.packageName}")))
            }) { Text("Overlay permission") }
        }
        item {
            TextButton(onClick = { ask.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)) }) {
                Text("Microphone and notification permission")
            }
        }

        item { Section("Privacy") }
        item { Toggle("Memory", settings.memoryEnabled) { checked -> save { it.copy(memoryEnabled = checked) } } }
        item { Toggle("Screen context", settings.screenContextEnabled) { checked -> save { it.copy(screenContextEnabled = checked) } } }
        item {
            Text("Screen context needs the accessibility service. JARVIS only keeps the latest visible text in memory, skips password fields, and does not tap or type.", color = Mist)
            TextButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Open accessibility settings") }
        }
        item { Toggle("Notification summaries", settings.notificationSummaryEnabled) { checked -> save { it.copy(notificationSummaryEnabled = checked) } } }
        item {
            TextButton(onClick = { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }) {
                Text("Notification access")
            }
        }
        item { Toggle("Place calls directly", settings.directCalling) { checked -> save { it.copy(directCalling = checked) } } }
        item { Text("Off by default. Even when on, JARVIS asks you first and refuses emergency numbers. Off means the dialer opens and you press call.", color = Mist) }
        item {
            TextButton(onClick = {
                ask.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA, Manifest.permission.READ_CALENDAR))
            }) { Text("Contacts, phone, camera, calendar") }
        }
        item {
            OutlinedTextField(
                exclude,
                { exclude = it },
                label = { Text("Excluded packages, comma separated") },
                modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = {
                val set = exclude.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                save { it.copy(excludedPackages = set) }
            }) { Text("Save exclude list") }
        }
        items(memories, key = { it.id }) { memory ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(memory.value, modifier = Modifier.weight(1f), color = Mist)
                TextButton(onClick = { scope.launch { container.memory.delete(memory.id) } }) { Text("Delete") }
            }
        }
        item {
            TextButton(onClick = { scope.launch { container.memory.forgetAll() } }) { Text("Delete all memory") }
        }

        item { Section("Developer") }
        item { Toggle("Keep debug notes", settings.debugLogs) { checked -> save { it.copy(debugLogs = checked) } } }
        item {
            TextButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "JARVIS logs")
                    putExtra(Intent.EXTRA_TEXT, DevLog.dump().ifBlank { "No logs yet." })
                }
                context.startActivity(Intent.createChooser(send, "Export logs"))
            }) { Text("Export logs") }
        }
        item {
            TextButton(onClick = {
                scope.launch {
                    container.settings.update { it.copy(onboardingDone = false) }
                }
            }) { Text("Replay onboarding") }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun Toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChoiceRow(label: String, options: List<String>, selected: String, onPick: (String) -> Unit) {
    Column {
        Text(label, color = Mist)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            options.forEach { option ->
                TextButton(onClick = { onPick(option) }) {
                    Text(if (option == selected) "[$option]" else option)
                }
            }
        }
    }
}
