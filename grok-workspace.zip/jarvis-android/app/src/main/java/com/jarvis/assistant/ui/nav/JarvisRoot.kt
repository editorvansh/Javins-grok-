package com.jarvis.assistant.ui.nav

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.data.db.MessageEntity
import com.jarvis.assistant.data.prefs.AssistantSettings
import com.jarvis.assistant.di.AppContainer
import com.jarvis.assistant.domain.model.AssistantPhase
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.ui.components.AssistantOrb
import com.jarvis.assistant.ui.onboarding.OnboardingScreen
import com.jarvis.assistant.ui.settings.SettingsScreen
import com.jarvis.assistant.ui.theme.Ink
import com.jarvis.assistant.ui.theme.InkCard
import com.jarvis.assistant.ui.theme.Mist
import kotlinx.coroutines.launch

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Outlined.Home),
    Tab("chat", "Chat", Icons.Outlined.Keyboard),
    Tab("history", "History", Icons.Outlined.History),
    Tab("auto", "Auto", Icons.Outlined.AutoAwesome),
    Tab("settings", "Settings", Icons.Outlined.Settings),
)

@Composable
fun JarvisRoot(
    container: AppContainer,
    settings: AssistantSettings,
    viewModel: JarvisViewModel,
) {
    if (!settings.onboardingDone) {
        OnboardingScreen(container = container, settings = settings)
        return
    }
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: "home"
    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Ink) {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding),
        ) {
            composable("home") { HomeScreen(settings, viewModel) { nav.navigate("actions") } }
            composable("chat") { ChatScreen(viewModel) }
            composable("history") { HistoryScreen(container) }
            composable("auto") { AutomationsScreen(container) }
            composable("actions") { ActionsScreen() }
            composable("settings") { SettingsScreen(container, settings) }
        }
    }
}

@Composable
private fun HomeScreen(settings: AssistantSettings, viewModel: JarvisViewModel, onTools: () -> Unit) {
    val phase by viewModel.phase.collectAsState()
    val amp by viewModel.amplitude.collectAsState()
    val status by viewModel.statusLine.collectAsState()
    val partial by viewModel.partial.collectAsState()
    val pending by viewModel.pendingPrompt.collectAsState()
    val error by viewModel.error.collectAsState()
    var typed by remember { mutableStateOf("") }
    var showKeyboard by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(28.dp))
        Text(settings.assistantName.uppercase(), style = MaterialTheme.typography.headlineLarge)
        Text(status, color = Mist, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        AssistantOrb(phase = phase, amplitude = amp)
        Spacer(Modifier.height(12.dp))
        Text(
            text = pending ?: error ?: partial.ifBlank { phaseLabel(phase) },
            color = if (error != null) MaterialTheme.colorScheme.error else Mist,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.weight(1f))
        if (showKeyboard) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Type instead") },
                singleLine = true,
            )
            TextButton(onClick = {
                viewModel.submit(typed)
                typed = ""
                showKeyboard = false
            }) { Text("Send") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { showKeyboard = !showKeyboard }) {
                Icon(Icons.Outlined.Keyboard, contentDescription = "Keyboard")
            }
            IconButton(onClick = { viewModel.toggleListen() }, modifier = Modifier.size(72.dp)) {
                Icon(Icons.Outlined.Mic, contentDescription = "Microphone", modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = { viewModel.stop() }) {
                Icon(Icons.Outlined.Stop, contentDescription = "Stop")
            }
        }
        TextButton(onClick = onTools) { Text("What I can do") }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ChatScreen(viewModel: JarvisViewModel) {
    val messages by viewModel.messages.collectAsState()
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { message ->
                val mine = message.role == com.jarvis.assistant.domain.model.ChatMessage.Role.USER
                Box(
                    Modifier.fillMaxWidth(),
                    contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart,
                ) {
                    Text(
                        message.text,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (mine) InkCard else MaterialTheme.colorScheme.surface)
                            .padding(12.dp),
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask JARVIS") },
            )
            TextButton(onClick = {
                viewModel.submit(text)
                text = ""
            }) { Text("Send") }
        }
    }
}

@Composable
private fun HistoryScreen(container: AppContainer) {
    val messages by container.history.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("History", style = MaterialTheme.typography.headlineMedium)
            TextButton(onClick = { scope.launch { container.history.clear() } }) { Text("Clear") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { item: MessageEntity ->
                Text("${item.role.lowercase()}: ${item.text}", color = Mist)
            }
        }
    }
}

@Composable
private fun ActionsScreen() {
    val rows = listOf(
        "Open apps, links, maps, camera, settings" to "Low risk",
        "Alarms, timers, reminders, calendar drafts" to "You confirm in the system app",
        "Calls and message drafts" to "JARVIS asks first, then Android asks again",
        "Flashlight, volume, media keys, battery, time" to "Low risk",
        "Notifications and screen text" to "Only after you opt in",
        "Shell, installs, payments, lock-screen changes" to "Blocked",
    )
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Actions", style = MaterialTheme.typography.headlineMedium) }
        item { Text("The model can only request these tools. Safety checks run in the app, not in the model.", color = Mist) }
        items(rows) { (title, risk) ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(InkCard).padding(14.dp),
            ) {
                Text(title)
                Text(risk, color = Mist, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

private fun phaseLabel(phase: AssistantPhase): String = when (phase) {
    AssistantPhase.IDLE -> "Say something, or tap the mic."
    AssistantPhase.LISTENING -> "Listening"
    AssistantPhase.THINKING -> "Thinking"
    AssistantPhase.SPEAKING -> "Speaking"
    AssistantPhase.EXECUTING -> "Working"
    AssistantPhase.ERROR -> "Something needs attention"
}
