package com.jarvis.assistant.security

/**
 * Refuses emergency, short-code, and star/hash service numbers.
 * JARVIS must never dial these on its own.
 */
object SensitiveNumberGuard {
    private val emergency = setOf(
        "911", "112", "999", "000", "100", "101", "102", "108", "110", "119", "15", "17", "18",
        "9111", "1122",
    )

    fun isBlocked(raw: String): Boolean {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return false
        if (trimmed.any { it == '*' || it == '#' }) return true
        val digits = trimmed.filter { it.isDigit() }
        if (digits.isEmpty()) return false
        if (digits.length <= 4 && digits in emergency) return true
        if (emergency.any { digits == it || digits.endsWith(it) && digits.length <= it.length + 1 }) {
            return digits.length <= 5
        }
        return false
    }
}
