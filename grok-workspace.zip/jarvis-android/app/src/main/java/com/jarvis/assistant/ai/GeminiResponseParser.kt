package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.JarvisAction
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

data class ParsedGemini(
    val text: String?,
    val actions: List<JarvisAction>,
)

object GeminiResponseParser {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parse(payload: String): ParsedGemini {
        if (payload.isBlank()) return ParsedGemini(null, emptyList())
        return try {
            val root = json.parseToJsonElement(payload).jsonObject
            val error = root["error"]?.jsonObject?.get("message")?.jsonPrimitive?.contentOrNull
            if (!error.isNullOrBlank()) {
                return ParsedGemini(text = null, actions = emptyList())
            }
            val texts = mutableListOf<String>()
            val actions = mutableListOf<JarvisAction>()
            val candidates = root["candidates"]?.jsonArray ?: JsonArray(emptyList())
            for (candidate in candidates) {
                val parts = candidate.jsonObject["content"]?.jsonObject?.get("parts")?.jsonArray ?: continue
                for (part in parts) {
                    val obj = part.jsonObject
                    val text = obj["text"]?.jsonPrimitive?.contentOrNull
                    if (!text.isNullOrBlank()) {
                        val loose = parseLooseJson(text)
                        if (loose != null && text.trim().startsWith("{")) {
                            actions += loose
                        } else {
                            texts += text.trim()
                        }
                    }
                    val call = obj["functionCall"]?.jsonObject ?: continue
                    val name = call["name"]?.jsonPrimitive?.contentOrNull ?: continue
                    val args = jsonObjectToMap(call["args"]?.jsonObject)
                    actions += ToolRouter.fromCall(name, args)
                }
            }
            ParsedGemini(texts.joinToString("\n").ifBlank { null }, actions.take(4))
        } catch (_: Exception) {
            ParsedGemini(null, emptyList())
        }
    }

    /**
     * Only accepts a payload that is entirely JSON. Prose that merely contains
     * a JSON snippet is ignored so quoted examples cannot execute.
     */
    fun parseLooseJson(text: String): JarvisAction? {
        val trimmed = text.trim()
        if (!trimmed.startsWith("{") || !trimmed.endsWith("}")) return null
        return try {
            val obj = json.parseToJsonElement(trimmed).jsonObject
            val name = obj["name"]?.jsonPrimitive?.contentOrNull
                ?: obj["action"]?.jsonPrimitive?.contentOrNull
                ?: return null
            val argsElement = obj["args"] ?: obj["parameters"] ?: obj["arguments"]
            val args = when (argsElement) {
                is JsonObject -> jsonObjectToMap(argsElement)
                else -> obj.filterKeys { it != "name" && it != "action" && it != "args" }
                    .mapValues { (_, value) -> primitive(value) }
            }
            ToolRouter.fromCall(name, args)
        } catch (_: Exception) {
            null
        }
    }

    private fun jsonObjectToMap(obj: JsonObject?): Map<String, Any?> {
        if (obj == null) return emptyMap()
        return obj.mapValues { (_, value) -> primitive(value) }
    }

    private fun primitive(value: kotlinx.serialization.json.JsonElement): Any? = when (value) {
        is JsonPrimitive -> when {
            value.isString -> value.content
            value.booleanOrNull != null -> value.booleanOrNull
            value.longOrNull != null -> value.longOrNull
            value.doubleOrNull != null -> value.doubleOrNull
            else -> value.contentOrNull
        }
        is JsonObject -> value.toString()
        is JsonArray -> value.joinToString(",")
        else -> null
    }
}
