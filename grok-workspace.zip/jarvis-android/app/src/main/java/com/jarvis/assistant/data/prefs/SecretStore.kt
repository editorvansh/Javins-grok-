package com.jarvis.assistant.data.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API keys live in app-private encrypted preferences, never in source.
 * Release builds do not seed from BuildConfig.
 */
class SecretStore(context: Context) {
    private val prefs: SharedPreferences = open(context.applicationContext)

    fun geminiKey(): String = prefs.getString(GEMINI, "").orEmpty()
    fun elevenLabsKey(): String = prefs.getString(ELEVEN, "").orEmpty()

    fun setGeminiKey(value: String) = prefs.edit().putString(GEMINI, value.trim()).apply()
    fun setElevenLabsKey(value: String) = prefs.edit().putString(ELEVEN, value.trim()).apply()

    fun seedIfBlank(gemini: String, eleven: String) {
        if (geminiKey().isBlank() && gemini.isNotBlank()) setGeminiKey(gemini)
        if (elevenLabsKey().isBlank() && eleven.isNotBlank()) setElevenLabsKey(eleven)
    }

    private fun open(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (_: Exception) {
            context.getSharedPreferences(FILE + "_fallback", Context.MODE_PRIVATE)
        }
    }

    private companion object {
        const val FILE = "jarvis_secrets"
        const val GEMINI = "gemini_api_key"
        const val ELEVEN = "elevenlabs_api_key"
    }
}
