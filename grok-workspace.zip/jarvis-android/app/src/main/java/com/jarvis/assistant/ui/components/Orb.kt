package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.domain.model.AssistantPhase
import com.jarvis.assistant.ui.theme.Blue
import com.jarvis.assistant.ui.theme.Cyan
import com.jarvis.assistant.ui.theme.Danger
import com.jarvis.assistant.ui.theme.Good
import kotlin.math.sin

@Composable
fun AssistantOrb(
    phase: AssistantPhase,
    amplitude: Float,
    modifier: Modifier = Modifier,
    size: Dp = 240.dp,
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing)),
        label = "spin",
    )
    val breathe by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "breathe",
    )
    val accent = when (phase) {
        AssistantPhase.LISTENING -> Cyan
        AssistantPhase.THINKING -> Color(0xFF9BB6FF)
        AssistantPhase.SPEAKING -> Color(0xFFD8FFF6)
        AssistantPhase.EXECUTING -> Good
        AssistantPhase.ERROR -> Danger
        AssistantPhase.IDLE -> Blue
    }
    Canvas(modifier.size(size)) {
        val r = this.size.minDimension / 2f
        val center = Offset(r, r)
        val pulse = when (phase) {
            AssistantPhase.LISTENING, AssistantPhase.SPEAKING -> 0.04f + amplitude.coerceIn(0f, 1f) * 0.12f + breathe * 0.03f
            AssistantPhase.THINKING -> 0.05f + sin(breathe * Math.PI).toFloat() * 0.04f
            else -> 0.03f + breathe * 0.02f
        }
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.55f), Color.Transparent),
                center = center,
                radius = r,
            ),
            radius = r * (0.92f + pulse),
            center = center,
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.9f), accent),
                center = Offset(center.x - r * 0.1f, center.y - r * 0.12f),
                radius = r * 0.45f,
            ),
            radius = r * (0.34f + pulse),
            center = center,
        )
        drawArc(
            color = Color.White.copy(alpha = 0.85f),
            startAngle = spin,
            sweepAngle = if (phase == AssistantPhase.THINKING) 80f else 36f + amplitude * 50f,
            useCenter = false,
            topLeft = Offset(r * 0.18f, r * 0.18f),
            size = Size(r * 1.64f, r * 1.64f),
            style = Stroke(width = 5f, cap = StrokeCap.Round),
        )
        drawArc(
            color = accent.copy(alpha = 0.7f),
            startAngle = spin + 140f,
            sweepAngle = 24f,
            useCenter = false,
            topLeft = Offset(r * 0.08f, r * 0.08f),
            size = Size(r * 1.84f, r * 1.84f),
            style = Stroke(width = 3f, cap = StrokeCap.Round),
        )
    }
}
