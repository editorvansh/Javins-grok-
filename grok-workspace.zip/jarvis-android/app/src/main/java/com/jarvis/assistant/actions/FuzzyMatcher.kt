package com.jarvis.assistant.actions

object FuzzyMatcher {
    fun normalize(raw: String): String =
        raw.lowercase()
            .replace('&', ' ')
            .replace(Regex("[^a-z0-9 ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun score(query: String, candidate: String): Int {
        val q = normalize(query)
        val c = normalize(candidate)
        if (q.isEmpty() || c.isEmpty()) return 0
        if (q == c) return 100
        if (c.startsWith(q) || q.startsWith(c)) return 92
        if (c.contains(q) || (q.length >= 4 && q.contains(c))) return 80
        val tokens = q.split(' ').filter { it.length > 1 }
        if (tokens.isNotEmpty() && tokens.all { c.contains(it) }) return 84
        val dist = levenshtein(q, c)
        val max = maxOf(q.length, c.length).coerceAtLeast(1)
        val ratio = 1.0 - dist.toDouble() / max
        return (ratio * 70).toInt().coerceIn(0, 70)
    }

    fun <T> rank(query: String, options: List<T>, label: (T) -> String, threshold: Int = 60): List<Pair<T, Int>> =
        options.map { it to score(query, label(it)) }
            .filter { it.second >= threshold }
            .sortedByDescending { it.second }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            for (j in prev.indices) prev[j] = cur[j]
        }
        return prev[b.length]
    }
}
