package com.jarvis.assistant.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.jarvis.assistant.data.db.AutomationDao
import com.jarvis.assistant.data.db.AutomationEntity
import com.jarvis.assistant.services.AutomationAlarmReceiver
import java.util.Calendar
import java.util.UUID

class AutomationManager(
    private val context: Context,
    private val dao: AutomationDao,
) {
    fun observe() = dao.observe()

    suspend fun all(): List<AutomationEntity> = dao.all()

    suspend fun save(name: String, hour: Int, minute: Int, daysMask: Int, prompt: String, enabled: Boolean, id: String? = null) {
        val entity = AutomationEntity(
            id = id ?: UUID.randomUUID().toString(),
            name = name.ifBlank { "Automation" }.take(60),
            hour = hour.coerceIn(0, 23),
            minute = minute.coerceIn(0, 59),
            daysMask = daysMask,
            prompt = prompt.take(300),
            enabled = enabled,
        )
        dao.upsert(entity)
        if (enabled) schedule(entity) else cancel(entity.id)
    }

    suspend fun setEnabled(entity: AutomationEntity, enabled: Boolean) {
        val next = entity.copy(enabled = enabled)
        dao.upsert(next)
        if (enabled) schedule(next) else cancel(next.id)
    }

    suspend fun delete(id: String) {
        cancel(id)
        dao.delete(id)
    }

    suspend fun rescheduleAll() {
        dao.all().forEach { item ->
            if (item.enabled) schedule(item) else cancel(item.id)
        }
    }

    suspend fun runDue(id: String, submit: suspend (String) -> Unit) {
        val item = dao.all().firstOrNull { it.id == id } ?: return
        if (item.enabled) schedule(item)
        val today = Calendar.getInstance()
        val bit = 1 shl today.get(Calendar.DAY_OF_WEEK)
        if (item.daysMask != 0 && (item.daysMask and bit) == 0) return
        val command = item.prompt.ifBlank { "What's on my schedule today, and how much battery do I have?" }
        submit(command)
    }

    private fun schedule(item: AutomationEntity) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        val pending = pending(item.id)
        val trigger = nextTrigger(item)
        val canExact = Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()
        if (canExact) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
        }
    }

    private fun cancel(id: String) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.cancel(pending(id))
    }

    private fun pending(id: String): PendingIntent {
        val intent = Intent(context, AutomationAlarmReceiver::class.java).apply {
            putExtra(AutomationAlarmReceiver.EXTRA_ID, id)
        }
        return PendingIntent.getBroadcast(
            context,
            id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun nextTrigger(item: AutomationEntity): Long {
        for (add in 0..8) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, add)
            cal.set(Calendar.HOUR_OF_DAY, item.hour)
            cal.set(Calendar.MINUTE, item.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis() + 15_000) continue
            val bit = 1 shl cal.get(Calendar.DAY_OF_WEEK)
            if (item.daysMask == 0 || (item.daysMask and bit) != 0) return cal.timeInMillis
        }
        return System.currentTimeMillis() + 86_400_000L
    }
}
