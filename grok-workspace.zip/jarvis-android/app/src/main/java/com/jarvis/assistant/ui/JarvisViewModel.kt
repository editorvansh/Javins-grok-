package com.jarvis.assistant.ui

import androidx.lifecycle.ViewModel
import com.jarvis.assistant.app.AssistantEngine
import com.jarvis.assistant.domain.model.AssistantPhase
import com.jarvis.assistant.domain.model.ChatMessage
import kotlinx.coroutines.flow.StateFlow

class JarvisViewModel(
    private val engine: AssistantEngine,
) : ViewModel() {
    val phase: StateFlow<AssistantPhase> = engine.phase
    val messages: StateFlow<List<ChatMessage>> = engine.messages
    val partial: StateFlow<String> = engine.partial
    val amplitude: StateFlow<Float> = engine.amplitude
    val pendingPrompt: StateFlow<String?> = engine.pendingPrompt
    val error: StateFlow<String?> = engine.error
    val statusLine: StateFlow<String> = engine.statusLine

    fun submit(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        engine.submit(clean)
    }

    fun toggleListen() = engine.toggleListen()

    fun stop() = engine.stop()
}
