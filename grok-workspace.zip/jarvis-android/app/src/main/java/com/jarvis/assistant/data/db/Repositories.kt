package com.jarvis.assistant.data.db

import com.jarvis.assistant.actions.FuzzyMatcher
import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.MemorySource

class MemoryRepository(private val dao: MemoryDao) : MemorySource {
    fun observe() = dao.observe()

    override suspend fun lines(): List<String> = dao.all().map { it.value }

    override suspend fun remember(fact: String) {
        val now = System.currentTimeMillis()
        dao.insert(MemoryEntity(value = fact.trim(), createdAt = now, updatedAt = now))
    }

    override suspend fun forgetMatch(query: String): Int {
        val hits = dao.all().filter { item ->
            item.value.contains(query, ignoreCase = true) || FuzzyMatcher.score(query, item.value) >= 72
        }
        hits.forEach { dao.delete(it.id) }
        return hits.size
    }

    suspend fun delete(id: Long) = dao.delete(id)

    override suspend fun forgetAll() = dao.deleteAll()
}

class HistoryRepository(private val dao: MessageDao) {
    fun observe() = dao.observe()

    suspend fun append(message: ChatMessage) {
        dao.insert(
            MessageEntity(
                role = message.role.name,
                text = message.text.take(4000),
                timestamp = message.timestamp,
            ),
        )
    }

    suspend fun clear() = dao.clear()
}
