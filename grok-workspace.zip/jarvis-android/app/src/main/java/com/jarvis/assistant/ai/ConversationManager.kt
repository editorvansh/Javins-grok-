package com.jarvis.assistant.ai

import com.jarvis.assistant.domain.model.ChatMessage
import com.jarvis.assistant.domain.model.JarvisAction
import java.util.ArrayDeque

class ConversationManager(
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    var timeoutMs: Long = 30_000L

    private var sessionUntil: Long = 0L
    private val turns = ArrayDeque<ChatMessage>()
    var pending: JarvisAction? = null
        private set

    fun isActive(now: Long = clock()): Boolean = now < sessionUntil

    fun noteActivity(now: Long = clock()) {
        sessionUntil = now + timeoutMs
    }

    fun purgeIfExpired(now: Long = clock()) {
        if (sessionUntil != 0L && now >= sessionUntil) {
            sessionUntil = 0L
            pending = null
        }
    }

    fun add(message: ChatMessage) {
        turns.addLast(message)
        while (turns.size > 40) turns.removeFirst()
        noteActivity(message.timestamp.takeIf { it > 0 } ?: clock())
    }

    fun history(): List<ChatMessage> = turns.toList()

    fun setPending(action: JarvisAction?) {
        pending = action
        if (action != null) noteActivity()
    }

    fun end() {
        sessionUntil = 0L
        pending = null
    }

    fun clearTranscript() {
        turns.clear()
        end()
    }
}
