package com.jarvis.assistant.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.R
import com.jarvis.assistant.logging.JarvisTags
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext as? JarvisApplication
        if (app == null) {
            pending.finish()
            return
        }
        app.scope.launch(Dispatchers.IO) {
            try {
                val settings = app.container.settings.snapshot()
                app.container.automations.rescheduleAll()
                if (settings.startOnBoot && (settings.wakeEnabled || settings.overlayEnabled)) {
                    JarvisForegroundService.start(context, JarvisForegroundService.ACTION_START)
                }
                app.container.logger.d(JarvisTags.SERVICE, "Boot completed. wake=${settings.wakeEnabled} overlay=${settings.overlayEnabled}")
            } catch (e: Exception) {
                app.container.logger.e(JarvisTags.SERVICE, "Boot handling failed", e)
            } finally {
                pending.finish()
            }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val message = intent?.getStringExtra(EXTRA_MESSAGE)?.take(180) ?: "Reminder"
        val app = context.applicationContext as? JarvisApplication
        val notification = NotificationCompat.Builder(context, JarvisForegroundService.CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_orb)
            .setContentTitle(app?.container?.let { "JARVIS" } ?: "JARVIS")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % 100000).toInt(), notification)
        } catch (_: SecurityException) {
            // Notification permission not granted.
        }
        app?.scope?.launch {
            app.container.engine.speakOut(message)
        }
    }

    companion object {
        const val EXTRA_MESSAGE = "message"
    }
}

class AutomationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getStringExtra(EXTRA_ID) ?: return
        val pending = goAsync()
        val app = context.applicationContext as? JarvisApplication
        if (app == null) {
            pending.finish()
            return
        }
        app.scope.launch(Dispatchers.IO) {
            try {
                app.container.automations.runDue(id) { command ->
                    app.container.engine.submitAndWait(command)
                }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val EXTRA_ID = "automation_id"
    }
}
