package com.jarvis.assistant

import com.jarvis.assistant.actions.FuzzyMatcher
import com.jarvis.assistant.ai.ConversationManager
import com.jarvis.assistant.ai.GeminiResponseParser
import com.jarvis.assistant.ai.LocalCommandParser
import com.jarvis.assistant.ai.ToolRouter
import com.jarvis.assistant.ai.Utterance
import com.jarvis.assistant.domain.model.JarvisAction
import com.jarvis.assistant.domain.model.RiskLevel
import com.jarvis.assistant.logging.LogRedactor
import com.jarvis.assistant.security.ActionSafetyManager
import com.jarvis.assistant.security.SensitiveNumberGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolRouterTest {
    @Test
    fun unknownToolIsRejected() {
        val action = ToolRouter.fromCall("run_shell", mapOf("command" to "rm -rf /"))
        assertTrue(action is JarvisAction.Rejected)
    }

    @Test
    fun confirmedFlagFromModelIsIgnored() {
        val action = ToolRouter.fromCall(
            "call_contact",
            mapOf("name" to "Rahul", "confirmed" to true, "force" to true, "bypass" to true),
        )
        assertTrue(action is JarvisAction.CallContact)
        assertEquals("Rahul", (action as JarvisAction.CallContact).name)
    }

    @Test
    fun openAppReadsAllowListedNamesOnly() {
        val action = ToolRouter.fromCall("open_app", mapOf("app_name" to "YouTube", "shell" to "adb reboot"))
        assertEquals(JarvisAction.OpenApp("YouTube"), action)
    }

    @Test
    fun malformedNumbersDoNotCrash() {
        val action = ToolRouter.fromCall("set_alarm", mapOf("hour" to "nope"))
        assertTrue(action is JarvisAction.Rejected)
    }
}

class GeminiResponseParserTest {
    private val safety = ActionSafetyManager()

    @Test
    fun malformedPayloadYieldsNoActions() {
        val parsed = GeminiResponseParser.parse("this is not json {oops")
        assertNull(parsed.text)
        assertTrue(parsed.actions.isEmpty())
    }

    @Test
    fun functionCallIsParsedAndStillNeedsConfirmation() {
        val payload = """
            {"candidates":[{"content":{"parts":[
              {"functionCall":{"name":"call_contact","args":{"name":"Rahul","confirmed":true}}}
            ]}}]}
        """.trimIndent()
        val parsed = GeminiResponseParser.parse(payload)
        val action = parsed.actions.single()
        assertTrue(action is JarvisAction.CallContact)
        assertEquals(RiskLevel.CONFIRMATION_REQUIRED, safety.classify(action).level)
    }

    @Test
    fun proseContainingJsonDoesNotExecute() {
        val text = "Sure, an example would be {\"name\":\"run_shell\",\"args\":{\"command\":\"reboot\"}} but I won't."
        assertNull(GeminiResponseParser.parseLooseJson(text))
        val wrapped = """{"candidates":[{"content":{"parts":[{"text":${jsonQuote(text)}}]}}]}"""
        val parsed = GeminiResponseParser.parse(wrapped)
        assertTrue(parsed.actions.isEmpty())
        assertTrue(parsed.text?.contains("run_shell") == true)
    }

    @Test
    fun entireJsonObjectCanBeAToolCall() {
        val action = GeminiResponseParser.parseLooseJson("""{"action":"open_app","app_name":"Spotify"}""")
        assertEquals(JarvisAction.OpenApp("Spotify"), action)
    }
}

private fun jsonQuote(text: String): String =
    "\"" + text.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

class ActionSafetyTest {
    private val safety = ActionSafetyManager()

    @Test
    fun shellIsBlockedEvenIfUserConfirmedConceptually() {
        val decision = safety.classify(JarvisAction.OpenApp("rm -rf /system"))
        assertEquals(RiskLevel.BLOCKED, decision.level)
    }

    @Test
    fun javascriptUrlBlocked() {
        assertEquals(RiskLevel.BLOCKED, safety.classify(JarvisAction.OpenUrl("javascript:alert(1)")).level)
        assertEquals(RiskLevel.BLOCKED, safety.classify(JarvisAction.OpenUrl("file:///sdcard/secret")).level)
    }

    @Test
    fun httpsIsLowRisk() {
        assertEquals(RiskLevel.LOW_RISK, safety.classify(JarvisAction.OpenUrl("https://example.com")).level)
    }

    @Test
    fun callAndMessageRequireConfirmation() {
        assertEquals(RiskLevel.CONFIRMATION_REQUIRED, safety.classify(JarvisAction.CallContact("Rahul")).level)
        assertEquals(
            RiskLevel.CONFIRMATION_REQUIRED,
            safety.classify(JarvisAction.SendMessageDraft("Rahul", "I'll be late", "sms")).level,
        )
    }

    @Test
    fun openingAnAppIsLowRisk() {
        assertEquals(RiskLevel.LOW_RISK, safety.classify(JarvisAction.OpenApp("YouTube")).level)
    }

    @Test
    fun securitySettingsBlocked() {
        assertEquals(RiskLevel.BLOCKED, safety.classify(JarvisAction.LaunchSettings("lockscreen")).level)
    }

    @Test
    fun rejectedToolsStayBlocked() {
        val decision = safety.classify(JarvisAction.Rejected("pm_install", "Installing APKs is blocked."))
        assertEquals(RiskLevel.BLOCKED, decision.level)
    }

    @Test
    fun deleteAllMemoryRequiresConfirmation() {
        assertEquals(
            RiskLevel.CONFIRMATION_REQUIRED,
            safety.classify(JarvisAction.ForgetMemory("", deleteAll = true)).level,
        )
    }
}

class SensitiveNumberTest {
    @Test
    fun blocksEmergencyAndStarCodes() {
        assertTrue(SensitiveNumberGuard.isBlocked("911"))
        assertTrue(SensitiveNumberGuard.isBlocked("112"))
        assertTrue(SensitiveNumberGuard.isBlocked("*21#"))
        assertFalse(SensitiveNumberGuard.isBlocked("+14155552671"))
    }
}

class LocalCommandParserTest {
    private val parser = LocalCommandParser(now = { 1_700_000_000_000L })

    @Test
    fun parsesClearCommands() {
        assertEquals(JarvisAction.OpenApp("YouTube"), parser.parse("open YouTube"))
        assertTrue(parser.parse("set an alarm for 7 pm") is JarvisAction.SetAlarm)
        assertEquals(
            JarvisAction.SetAlarm(19, 0, "Alarm"),
            parser.parse(Utterance.stripWake("Jarvis, set an alarm for 7 pm", "Jarvis")),
        )
        assertEquals(JarvisAction.SetTimer(300, "Timer"), parser.parse("set a timer for 5 minutes"))
        val draft = parser.parse("message Rahul that I will be late")
        assertTrue(draft is JarvisAction.SendMessageDraft)
        assertEquals("I will be late", (draft as JarvisAction.SendMessageDraft).body)
    }

    @Test
    fun doesNotHijackCasualSpeech() {
        assertNull(parser.parse("I might call mom later"))
        assertNull(parser.parse("hello there"))
    }
}

class ConversationManagerTest {
    @Test
    fun pendingExpiresWithSession() {
        var now = 1_000L
        val manager = ConversationManager { now }
        manager.timeoutMs = 1_000
        manager.setPending(JarvisAction.CallContact("Rahul"))
        assertTrue(manager.isActive())
        now = 3_000
        manager.purgeIfExpired()
        assertNull(manager.pending)
        assertFalse(manager.isActive())
    }
}

class UtteranceTest {
    @Test
    fun wakeWordStripsAndDetects() {
        assertTrue(Utterance.isWakeOnly("Hey Jarvis", "Jarvis"))
        assertEquals("open Spotify", Utterance.stripWake("Jarvis, open Spotify", "Jarvis"))
        assertTrue(Utterance.isAffirmative("Yes"))
        assertTrue(Utterance.isNegative("never mind"))
        assertFalse(Utterance.isAffirmative("yes do the other thing later"))
    }
}

class FuzzyMatcherTest {
    @Test
    fun exactBeatsPartial() {
        assertEquals(100, FuzzyMatcher.score("YouTube", "YouTube"))
        assertTrue(FuzzyMatcher.score("youtube", "YouTube Music") >= 70)
        assertTrue(FuzzyMatcher.score("Spotify", "Calculator") < 60)
    }
}

class LogRedactorTest {
    @Test
    fun stripsKeys() {
        val clean = LogRedactor.redact("key=AIzaSyDUMMYKEY123456789012345 and xi-api-key: super-secret")
        assertFalse(clean.contains("AIza"))
        assertFalse(clean.contains("super-secret"))
    }
}
