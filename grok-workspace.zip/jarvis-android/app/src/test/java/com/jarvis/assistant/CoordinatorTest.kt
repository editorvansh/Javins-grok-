package com.jarvis.assistant

import com.jarvis.assistant.ai.AssistantCoordinatorImpl
import com.jarvis.assistant.ai.ConversationManager
import com.jarvis.assistant.ai.LocalCommandParser
import com.jarvis.assistant.domain.model.ActionGateway
import com.jarvis.assistant.domain.model.ActionResult
import com.jarvis.assistant.domain.model.AssistantConfig
import com.jarvis.assistant.domain.model.AssistantConfigSource
import com.jarvis.assistant.domain.model.BrainResult
import com.jarvis.assistant.domain.model.GeminiBrain
import com.jarvis.assistant.domain.model.JarvisAction
import com.jarvis.assistant.domain.model.MemorySource
import com.jarvis.assistant.domain.model.PlanRequest
import com.jarvis.assistant.security.ActionSafetyManager
import com.jarvis.assistant.ui.JarvisViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoordinatorTest {
    @Test
    fun modelCannotSkipCallConfirmation() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(BrainResult(null, listOf(JarvisAction.CallContact("Rahul")))),
            gateway = gateway,
        )
        val first = coordinator.handleText("call Rahul")
        assertTrue(gateway.calls.isEmpty())
        assertTrue(first.pendingPrompt?.contains("Rahul") == true)

        val second = coordinator.handleText("yes")
        assertEquals(1, gateway.calls.size)
        assertTrue(gateway.calls.single().second)
        assertTrue(second.spokenText.contains("did"))
    }

    @Test
    fun blockedToolNeverReachesGateway() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(
                BrainResult(
                    null,
                    listOf(JarvisAction.Rejected("run_shell", "I can't run \"run_shell\". It isn't in the allowed tool list.")),
                ),
            ),
            gateway = gateway,
        )
        val result = coordinator.handleText("reboot the phone")
        assertTrue(gateway.calls.isEmpty())
        assertTrue(result.spokenText.contains("allowed") || result.error != null)
    }

    @Test
    fun dangerousUrlIsBlockedBeforeExecution() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(BrainResult("opening", listOf(JarvisAction.OpenUrl("javascript:alert(1)")))),
            gateway = gateway,
        )
        val result = coordinator.handleText("open it")
        assertTrue(gateway.calls.isEmpty())
        assertTrue(result.spokenText.contains("http") || result.error != null)
    }

    @Test
    fun lowRiskActionRunsWithoutConfirmation() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(BrainResult(null, listOf(JarvisAction.OpenApp("YouTube")))),
            gateway = gateway,
        )
        coordinator.handleText("open YouTube")
        assertEquals(false, gateway.calls.single().second)
    }

    @Test
    fun offlineParserStillOpensAppsWhenBrainFails() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(BrainResult(null, emptyList(), failure = "I can't reach Gemini right now. Check your connection.")),
            gateway = gateway,
        )
        val result = coordinator.handleText("open Spotify")
        assertTrue(gateway.calls.single().first is JarvisAction.OpenApp)
        assertTrue(result.error == null)
    }

    @Test
    fun sayingNoCancelsPending() = runBlocking {
        val gateway = RecordingGateway()
        val coordinator = coordinator(
            brain = ScriptBrain(BrainResult(null, listOf(JarvisAction.SendMessageDraft("Rahul", "running late", "sms")))),
            gateway = gateway,
        )
        coordinator.handleText("message him")
        val result = coordinator.handleText("no")
        assertTrue(gateway.calls.isEmpty())
        assertTrue(result.spokenText.contains("won't"))
    }
}

class JarvisViewModelTest {
    @Test
    fun submitForwardsTrimmedTextAndIgnoresBlank() {
        val engine = FakeEngine()
        val viewModel = JarvisViewModel(engine)
        viewModel.submit("   ")
        assertNull(engine.submitted)
        viewModel.submit("  what time is it  ")
        assertEquals("what time is it", engine.submitted)
        viewModel.toggleListen()
        assertEquals(com.jarvis.assistant.domain.model.AssistantPhase.LISTENING, viewModel.phase.value)
        viewModel.stop()
        assertEquals(com.jarvis.assistant.domain.model.AssistantPhase.IDLE, viewModel.phase.value)
    }
}

private class ScriptBrain(private val result: BrainResult) : GeminiBrain {
    override suspend fun plan(request: PlanRequest): BrainResult = result
}

private class RecordingGateway : ActionGateway {
    val calls = mutableListOf<Pair<JarvisAction, Boolean>>()
    override suspend fun run(action: JarvisAction, confirmedByUser: Boolean): ActionResult {
        calls += action to confirmedByUser
        return ActionResult.Success("did ${action::class.simpleName}")
    }
}

private class EmptyMemory : MemorySource {
    override suspend fun lines(): List<String> = emptyList()
    override suspend fun remember(fact: String) = Unit
    override suspend fun forgetMatch(query: String): Int = 0
    override suspend fun forgetAll() = Unit
}

private fun coordinator(brain: GeminiBrain, gateway: ActionGateway) = AssistantCoordinatorImpl(
    brain = brain,
    local = LocalCommandParser(),
    safety = ActionSafetyManager(),
    gateway = gateway,
    memory = EmptyMemory(),
    config = AssistantConfigSource { AssistantConfig() },
    conversation = ConversationManager(),
)

private class FakeEngine : com.jarvis.assistant.app.AssistantEngine {
    override val phase = MutableStateFlow(com.jarvis.assistant.domain.model.AssistantPhase.IDLE)
    override val messages = MutableStateFlow<List<com.jarvis.assistant.domain.model.ChatMessage>>(emptyList())
    override val partial = MutableStateFlow("")
    override val amplitude = MutableStateFlow(0f)
    override val pendingPrompt = MutableStateFlow<String?>(null)
    override val error = MutableStateFlow<String?>(null)
    override val statusLine = MutableStateFlow("Ready")
    var submitted: String? = null
    override fun submit(text: String) {
        submitted = text
    }
    override fun toggleListen() {
        phase.value = com.jarvis.assistant.domain.model.AssistantPhase.LISTENING
    }
    override fun stop() {
        phase.value = com.jarvis.assistant.domain.model.AssistantPhase.IDLE
    }
}
